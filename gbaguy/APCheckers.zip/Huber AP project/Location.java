//a simple class to store an X,Y rectangular coordinates

class Location 
{
	public int X;
	public int Y;

	public Location(int x,int y)
	{
		X = x;
		Y = y;
	}
}
