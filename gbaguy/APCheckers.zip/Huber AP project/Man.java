import javax.swing.*;
import java.awt.*;

//class stores info about a checker piece (called a "man")

class Man 
{
	private static int PlayerColor = 0; // 0 == nothing, 1 == black, 2 == red
	private CheckerBoard board;
	private boolean IsBlack;
	private boolean IsKing = false;
	private boolean IsSelected = false;

	public static void Reset()
	{
		PlayerColor = 0;
	}

	public static int getPlayerColor()
	{
		return PlayerColor;
	}

	public boolean setSelected(boolean sel)
	{
		if(sel&&PlayerColor==0)
			if(IsBlack)
				PlayerColor=1;
			else
				PlayerColor=2;
		if(PlayerColor==1 && !IsBlack) return false;
		if(PlayerColor==2 && IsBlack) return false;
		IsSelected = sel;
		board.updateUI();
		return true;
	}

	public void captured()
	{
		board.removeMan(this);
	}

	public boolean isSelected()
	{
		return IsSelected;
	}

	public Man(CheckerBoard b)
	{
		board = b;	
		IsBlack = true;
	}

	public Man(CheckerBoard b, boolean blck)
	{
		board = b;
		IsBlack = blck;
	}

	public void promoteToKing()
	{
		if(board.isEligibleKing(this))
		{
			IsKing = true;
		}
	}

	public void setKing(boolean d)
	{
	//needed for the Network class (it's less OO designed like this, but it's just plain easier.).
		IsKing = d;
	}

	public boolean isKing()
	{
	//returns true if this man is a king.
		return IsKing;
	}
	
	public boolean isBlack()
	{
	//returns true if this man is black.
		return IsBlack;
	}

	public boolean isRed()
	{
	//returns true if this man is red.
		return !IsBlack;
	}

	public void render(Graphics2D g)
	{
	//this method will draw this man, taking into account the following:
	//red/black,king/not king,selected/not selected
	
	//get the size and location of this man
		int size = board.getBoardWidth()/8;
		Location loc = board.getManLocation(this);

	//draw the man (save the color and reinstate it afterwards
		Color c = g.getColor();
		if(IsBlack)
			g.setColor(Color.black);
		else
			g.setColor(Color.red);
		g.fillOval(loc.X*size,loc.Y*size,size,size);
		if(IsSelected)
		{
			g.setColor(Color.green);
			BasicStroke bs =(BasicStroke) g.getStroke();
			g.setStroke(new BasicStroke(4));
			g.drawOval(loc.X*size,loc.Y*size,size,size);
			g.setStroke(bs);
		}
		if(IsKing)
		{
			g.setColor(Color.white);
			g.fillOval((loc.X*size)+(size/2),(loc.Y*size)+(size/2),size/4,size/4);
		}
		g.setColor(c);
	}

	public String toString()
	{
		if(isRed() && isKing()) return "rk";
		if(isBlack() && isKing()) return "bk";
		if(isBlack()) return "b";
		else return "r";
	}

}
