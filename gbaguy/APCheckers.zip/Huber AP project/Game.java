import javax.swing.*;
import java.awt.*;

class Game
{
	CheckerBoard board;
		
	public Game(CheckerBoard b)
	{
		board = b;
	}

	public void NewGame1Player()
	{
		board.InitializeMen();
		board.repaint();
		JOptionPane.showMessageDialog(null,"Please select a piece to choose your color.","APCheckers",JOptionPane.INFORMATION_MESSAGE);
	}

	public void RedWins() {}
	public void BlackWins() {}
	public int isThereAWinner()
	{
		boolean redLeft = false;
		for(int x=0;x<8;x++)
		for(int y=0;y<8;y++) 
		{
			if(board.getManAt(x,y)==null) continue;
			if(board.getManAt(x,y).isBlack()) continue;
			redLeft = true;
		}
		if(!redLeft)
			return 0;
		boolean blackLeft = false;
		for(int x=0;x<8;x++)
		for(int y=0;y<8;y++) 
		{
			if(board.getManAt(x,y)==null) continue;
			if(board.getManAt(x,y).isRed()) continue;
			blackLeft = true;
		}
		if(!blackLeft)
			return 1;
		return -1;
	}

	private boolean TryToJumpMan(Man man,int x,int y,boolean compBlack)
	{
	//method will jump a selected computer man.
		if(x+2<8 && y+2<8)
		{
			if(compBlack && !man.isKing())
				;
			else if(board.getManAt(x+2,y+2)==null)
			{
				if(board.getManAt(x+1,y+1)==null)
					;
				else if(board.getManAt(x+1,y+1).isBlack()==compBlack)
					;
				else {
					board.MoveMan(man,x+2,y+2);
					board.getManAt(x+1,y+1).captured();
					return true;
				}
			}
		}
		if(x-2>0 && y-2>0)
		{
			if(!compBlack && !man.isKing())
				;
			else if(board.getManAt(x-2,y-2)==null)
			{
				if(board.getManAt(x-1,y-1)==null)
					;
				else if(board.getManAt(x-1,y-1).isBlack()==compBlack)
					;
				else {
					board.MoveMan(man,x-2,y-2);
					board.getManAt(x-1,y-1).captured();
					return true;
				}
			}
		}
		if(x-2>0 && y+2<8)
		{
			if(compBlack && !man.isKing())
				;
			else if(board.getManAt(x-2,y+2)==null)
			{
				if(board.getManAt(x-1,y+1)==null)
					;
				else if(board.getManAt(x-1,y+1).isBlack()==compBlack)
					;
				else {
					board.MoveMan(man,x-2,y+2);
					board.getManAt(x-1,y+1).captured();
					return true;
				}
			}
		}
		if(x+2<8 && y-2>0)
		{
			if(!compBlack && !man.isKing())
				;
			else if(board.getManAt(x+2,y-2)==null)
			{
				if(board.getManAt(x+1,y-1)==null)
					;
				else if(board.getManAt(x+1,y-1).isBlack()==compBlack)
					;
				else {
					board.MoveMan(man,x+2,y-2);
					board.getManAt(x+1,y-1).captured();
					return true;
				}
			}
		}
		return false;
	}

	private boolean TryToMoveMan(Man man,int x,int y,boolean compBlack)
	{
	//method will move a selected computer man.
	
		//the plain moves
		if(x+1<8 && y+1<8)
		{
			if(compBlack && !man.isKing())
				;
			else if(board.getManAt(x+1,y+1)==null)
			{
				board.MoveMan(man,x+1,y+1);
				return true;	
			}
		}
		if(x-1>0 && y+1<8)
		{
			if(compBlack && !man.isKing())
				;
			else if(board.getManAt(x-1,y+1)==null)
			{
				board.MoveMan(man,x-1,y+1);
				return true;	
			}
		}
		if(x-1>0 && y-1>0)
		{
			if(!compBlack && !man.isKing())
				;
			else if(board.getManAt(x-1,y-1)==null)
			{
				board.MoveMan(man,x-1,y-1);
				return true;	
			}
		}
		if(x+1<8 && y-1>0)
		{
			if(!compBlack && !man.isKing())
				;
			else if(board.getManAt(x+1,y-1)==null)
			{
				board.MoveMan(man,x+1,y-1);
				return true;	
			}
		}

		//System.out.println("Didn't move");
		return false;
	}

	public int ComputerTurn()
	{
	//this method does the turn of the computer, this won't be too smart but it will work/be functional.

		board.repaint();

		int Winner = isThereAWinner();
		if(Winner!=-1)
			return Winner;
		
		boolean compIsBlack = (Man.getPlayerColor()==1) ? false : true;
		Man m = null;
		// try to jump a man
		for(int x=0;x<8;x++)
		for(int y=7;y>=0;y--)
		{
		try {
			m = board.getManAt(x,y);
			if(m==null)
				continue;
			if((m.isRed() && !compIsBlack) || (m.isBlack() && compIsBlack)) 
				if(TryToJumpMan(m,x,y,compIsBlack))
				{
					//System.out.println("MOVED");
					m.promoteToKing();
					return isThereAWinner();
				}
		} catch(Exception e) {System.out.println(e);}
		}
		
		//ok, let's move a man
		for(int x=0;x<8;x++)
		for(int y=0;y<8;y++)
		{
		try {
			m = board.getManAt(x,y);
			if(m==null)
				continue;
			if((m.isRed() && !compIsBlack) || (m.isBlack() && compIsBlack)) 
				if(TryToMoveMan(m,x,y,compIsBlack))
				{
					//System.out.println("MOVED");
					m.promoteToKing();
					return isThereAWinner();
				}
		} catch(Exception e) {System.out.println(e);}
		}
		return -1;
	}	

	private boolean canJumpMore(Man man)
	{
		Location loc = board.getManLocation(man);
		Man miw = board.getManAt(loc.X+1,loc.Y+1);
		if((miw==null) || (miw.isBlack() && Man.getPlayerColor()==1) || (miw.isRed() && Man.getPlayerColor()==2))
			;
		else
			return true;
		miw = board.getManAt(loc.X+1,loc.Y-1);
		if((miw==null) || (miw.isBlack() && Man.getPlayerColor()==1) || (miw.isRed() && Man.getPlayerColor()==2))
			;
		else
			return true;
		miw = board.getManAt(loc.X-1,loc.Y+1);
		if((miw==null) || (miw.isBlack() && Man.getPlayerColor()==1) || (miw.isRed() && Man.getPlayerColor()==2))
			;
		else
			return true;
		miw = board.getManAt(loc.X-1,loc.Y-1);
		if((miw==null) || (miw.isBlack() && Man.getPlayerColor()==1) || (miw.isRed() && Man.getPlayerColor()==2))
			;
		else
			return true;
		return false;
	}

	public boolean moveSelectedTo(int x,int y) 
	{
	// this method does the validating and actual moving of a player move.
		board.repaint();

		Man curSelected = board.getSelectedMan();
		Location loc = board.getManLocation(curSelected);
		
		System.out.println(x + "x" + y);

		int xDif,yDif;
		xDif = loc.X-x;
		yDif = loc.Y-y;
		if(xDif<0) xDif *= -1;
		if(yDif<0) yDif *= -1;

		if(board.getManAt(x,y)!=null)
		{
		//there's a man in that spot
			System.out.println("Man there");
			beep();
			return false;
		}
		if(loc.Y==y || loc.X==x)
		{
		//can't move straight, only diagonally
			System.out.println("diag. only");
			beep();
			return false;
		}
		if(y<loc.Y && !curSelected.isKing() && Man.getPlayerColor()==2)
		{
		//can't move backwards, you're not a king
			System.out.println("no backwards");
			beep();
			return false;
		}
		if(y>loc.Y && !curSelected.isKing() && Man.getPlayerColor()==1)
		{
		//can't move backwards, you're not a king
			System.out.println("no backwards");
			beep();
			return false;
		}
		if(yDif>=3 || xDif>=3)
		{
			beep();
			return false;
		}
		if((yDif>=2 && xDif==1) || (yDif==1 && xDif>=2))
		{
			beep();
			return false;
		}
		if(yDif==2 && xDif==2)
		{
			System.out.println("JUMP");
			int xf = loc.X-x;
			int yf = loc.Y-y;
			yf = (yf<0) ? -1 : 1;	
			xf = (xf<0) ? -1 : 1;
								
			Man miw = board.getManAt(x+xf,y+yf);
			if((miw==null) || (miw.isBlack() && Man.getPlayerColor()==1) || (miw.isRed() && Man.getPlayerColor()==2)) 
			{
				System.out.println("Invalid jump");
				beep();
				return false;
			}
			miw.captured();
			board.MoveMan(curSelected,new Location(x,y));
			curSelected.promoteToKing();
			//if(canJumpMore(curSelected))
			//	return;
		} else {
			board.MoveMan(curSelected,new Location(x,y));
			curSelected.promoteToKing();
		}
		board.repaint();
		return true;
	}

	public void beep()
	{
		Toolkit.getDefaultToolkit().beep();
	}
}
