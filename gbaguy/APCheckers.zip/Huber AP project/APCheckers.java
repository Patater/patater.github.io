import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

class APCheckers extends JFrame implements ActionListener {

	private Game game;
	private CheckerBoard board;
	private JPanel pane;

	private JMenuBar mnuMenubar = new JMenuBar();

	private JMenu mnuGame = new JMenu("Game");
	private JMenuItem mnuNewGame = new JMenuItem("New Game");
	private JMenuItem mnuExit = new JMenuItem("Exit");

	private JMenu mnuNetworked = new JMenu("NetPlay");
	//private JMenuItem mnuHostGame = new JMenuItem("Host Game");
	//private JMenuItem mnuClientGame = new JMenuItem("Connect");

	private JMenu mnuHelp = new JMenu("Help");
	private JMenuItem mnuInstr = new JMenuItem("Instructions");
	private JMenuItem mnuAbout = new JMenuItem("About");

	public APCheckers(String title) {
		super(title);
		board = new CheckerBoard(this);
	
		mnuGame.add(mnuNewGame);
		mnuGame.add(mnuExit);
	
		mnuHelp.add(mnuInstr);
		mnuHelp.add(mnuAbout);

		mnuMenubar.add(mnuGame);
		mnuMenubar.add(mnuHelp);

		this.setJMenuBar(mnuMenubar);
		this.pack();
		this.setSize(300,300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.show();

		mnuNewGame.addActionListener(this);
		mnuInstr.addActionListener(this);
		mnuAbout.addActionListener(this);
		mnuExit.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
	//I really wish switch could use strings like in C# and Visual Basic.NET...
		if(e.getActionCommand().equals("New Game"))
		{
			game = new Game(board);
			game.NewGame1Player();
			board.setGame(game);
		}
		if(e.getActionCommand().equals("Exit"))
		{
			System.exit(0);
		}
		if(e.getActionCommand().equals("Instructions"))
		{
			String k = "Click Game->New Game, you will be told to click a piece to choose your color.\n";
			k += "Select pieces with the left mouse button. Select an empty spot to goto with the right\n";
			k += "mouse button. The computer moves right after you do, so sometimes it'll look like nothing\n";
			k += "happened if you were jumped after a jump. Both you and the computer can only jump one player\n";
			k += "at a time; jumping is not required. King'ing is automatic.";
			JOptionPane.showMessageDialog(null,k,"APCheckers v0.2.0",JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getActionCommand().equals("About"))
		{
			String t = "APCheckers v0.2.0 by Mike Huber\nAPCheckers will be GPL after grade is received.\n";
			t += "Have fun!";
			JOptionPane.showMessageDialog(null,t,"APCheckers v0.2.0",JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public static void main(String[] args) {
		try {                                                               
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}                                                                   
		catch(Exception e) {}  
		APCheckers CheckersGame = new APCheckers("APCheckers v0.2.0");
	}
}
