import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class CheckerBoard extends JComponent implements MouseListener
{
	//array to store man references in semi-board form.
	private Man[][] board;
	private Game game;
	
	//variables to store the current board size (these are kept 8x8 proportional).
	private int bWidth;
	private int bHeight;

	//accessors that return board size.
	public int getBoardWidth() { return bWidth; }
	public int getBoardHeight() { return bHeight; }

	public void clearBoard()
	{
		for(int i=0;i<8;i++)
		for(int a=0;a<8;a++)
		{
			board[i][a] = null;
		}
	}

	public void PlaceMan(Man m,int x,int y)
	{
		board[x][y] = m;
	}

	public void removeMan(Man m)
	{
	//removes a man from the board.
		Location loc = getManLocation(m);
		if(loc!=null)
			board[loc.X][loc.Y] = null;
	}

	public void MoveMan(Man m, Location newLoc)
	{
	//moves a man to a new spot
		removeMan(m);
		board[newLoc.X][newLoc.Y] = m;	
		repaint();
	}

	public void MoveMan(Man m, int x, int y)
	{
	//moves a man to a new spot
		removeMan(m);
		board[x][y] = m;	
		repaint();
	}

	public boolean doesRedWin()
	{
	//will look at the board and see if red has won.
		return false;
	}

	public boolean doesBlackWin()
	{
	//will look at the board and see if black has won.
		return false;
	}

	public Man getSelectedMan()
	{
	//returns the currently selected man or null if none.
		for(int x=0;x<8;x++)
		for(int y=0;y<8;y++)
			if(board[x][y]!=null)
				if(board[x][y].isSelected())
					return board[x][y];
		return null;
	}

	public void deselectAllMen()
	{
	//this makes all men not selected.
		for(int x=0;x<8;x++)
		for(int y=0;y<8;y++)
			if(board[x][y]!=null)
				board[x][y].setSelected(false);
	}

	public void mouseReleased(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}

	public void mouseClicked(MouseEvent e) 
	{
	//responds to click events (actionPerformed defined in ActionListener interface).
	
		if(e.getButton()==MouseEvent.BUTTON1)
		{
			int x = e.getX();
			int y = e.getY();
		
			if(x>bWidth || y>bHeight) return; // didn't click on the board.

			x = x/(bWidth/8);
			y = y/(bHeight/8);

			Man m2 = getSelectedMan();

			if(board[x][y]!=null && board[x][y]!=m2)
				if(board[x][y].setSelected(true))
				{
					if(m2!=null)
						m2.setSelected(false);
				}
			repaint();
		}
		if(e.getButton()==MouseEvent.BUTTON3) // BUTTON3 should be the right mouse button
		{
			System.out.println("mouse down");
			int x = e.getX();
			int y = e.getY();
		
			if(x>bWidth || y>bHeight) return; // didn't click on the board.

			x = x/(bWidth/8);
			y = y/(bHeight/8);
		
			int w = -1;
			if(game.moveSelectedTo(x,y))
				w = game.ComputerTurn();
			if(w==-1) return;
			if((w==0 && Man.getPlayerColor()==1)||(w==1 && Man.getPlayerColor()==2))
			{
				JOptionPane.showMessageDialog(null, "You win!", "APCheckers", JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "You lose!", "APCheckers", JOptionPane.INFORMATION_MESSAGE);
			}
			Man.Reset();
			clearBoard();
		}
	}

	public Location getManLocation(Man m)
	{
	//method returns the X,Y of the man
	//returns null if man not found.
		
		for(int i=0;i<8;i++)
		for(int a=0;a<8;a++)
			if(board[a][i]==m)
				return new Location(a,i);
		return null;
	}

	public Man getManAt(int x,int y)
	{
	//gets the man at specified location, null if empty
		return board[x][y];
	}

	public boolean isEligibleKing(Man man)
	{
	//this method determines if a man is eligible to be a king.

		Location loc = getManLocation(man);
		if(man.isRed())
			if(loc.Y==7)
				return true;
			else
				return false;
		else
			if(loc.Y==0)
				return true;
			else
				return false;
	}

	public void InitializeMen()
	{
	//this method initializes the game.
		for(int x=0;x<8;x++)
		for(int y=0;y<8;y++)
			board[x][y] = null;	

	//place the red ones on the board.
		for(int a=0;a<3;a++)
		{
			if(a%2!=0)
			{
				board[0][a] = new Man(this, false);
				//TAKEOUT: this is just to see the selection code work.
				//board[0][a].setSelected(true);
				board[2][a] = new Man(this, false);
				board[4][a] = new Man(this, false);
				board[6][a] = new Man(this, false);
			} else {
				board[1][a] = new Man(this, false);
				board[3][a] = new Man(this, false);
				board[5][a] = new Man(this, false);
				board[7][a] = new Man(this, false);
			}
		}

	//place the black ones on the board.
		for(int a=0;a<3;a++)
		for(int b=0;b<8;b++)
		{
			if(a%2==0)
			{
				board[0][7-a] = new Man(this, true);
				board[2][7-a] = new Man(this, true);
				board[4][7-a] = new Man(this, true);
				board[6][7-a] = new Man(this, true);
			} else {
				board[1][7-a] = new Man(this, true);
				board[3][7-a] = new Man(this, true);
				board[5][7-a] = new Man(this, true);
				board[7][7-a] = new Man(this, true);
			}
		}
	}

	public CheckerBoard(JFrame parent)
	{
	//for simplicity, I like to add components to their parent in
	//their constructor.
		parent.getContentPane().add(this);
		this.addMouseListener(this);
		board = new Man[8][8];
	}

	protected void paintComponent(Graphics g) {
	//This method paints the board
	//the two board colors are a greenish (119,162,109), and a yellow
	//-ish (200,195,101)
		Color sq1 = new Color(119,162,109);
		Color sq2 = new Color(200,195,101);

	//call the JComponent's version of the method, needs to be done
	//and cast to a Graphics2D object, has more features than the old Graphics.
	//then clear the board.
		super.paintComponent(g);
		Graphics2D g2d =(Graphics2D) g;
		g2d.clearRect(0,0,getWidth(),getHeight());
			
	//draw the 8x8 checkers board, each square will be proportional to the
	//current size of the board (which will be cut to the highest possible
	//multiple of 8 that doesn't go past the size of the JFrame).
		int w = getWidth();
		int h = getHeight();
		int x = (w<h) ? w : h;
		x = (x-(x%8));
		h = w = x;
		bWidth = w;
		bHeight = h;
		g2d.fillRect(0,0,getWidth(),getHeight());
		x /= 8;

	//var x will be reused for size of individual squares
		for(int b=0;b<8;b++)
		for(int a=0;a<8;a+=2)
		{
			if(b%2==0)  //using even or odd, we can alternate the starting
				    //color so we get the checker board effect.
			{
				g2d.setColor(sq2);
				g2d.fillRect(a*x,b*x,x,x);
				g2d.setColor(sq1);
				g2d.fillRect((a+1)*x,b*x,x,x);
			} else {
				g2d.setColor(sq1);
				g2d.fillRect(a*x,b*x,x,x);
				g2d.setColor(sq2);
				g2d.fillRect((a+1)*x,b*x,x,x);
			}
		}

	//draw the Men
		for(int a=0;a<8;a++)
		for(int b=0;b<8;b++)
			if(board[a][b]!=null)
				board[a][b].render(g2d);
	}
	
	public void setGame(Game g)
	{
		game = g;
	}
}
