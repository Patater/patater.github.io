using System;
using System.IO;
using System.Collections;
using System.Windows.Forms;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.ComponentModel;
using System.Timers;

public class IRC : Form {
	MenuItem mnuFile = new MenuItem("&File");
	MenuItem mnuConnect = new MenuItem("Connect");	
	MenuItem mnuExit = new MenuItem("Exit");
	MenuItem mnuOptions = new MenuItem("Options");
	MenuItem mnuPrefs = new MenuItem("Preferences");
	MenuItem mnuViewMOTD = new MenuItem("View MOTD");
	public static TcpClient TC;
	public static StreamReader SR;
	public static StreamWriter SW;
	public static bool Running = false;
	public static bool Initialized = false;
	public static string NICK = "Guest4296";
	public static Stack channelstack = new Stack();
	public static Hashtable Channels = new Hashtable();
	public static string MOTD = "";
	Channel server;
	Preferences Prefs;
	
	[System.Runtime.InteropServices.DllImport("kernel32.dll")]
	private static extern void ExitProcess();
	
	public IRC() {
		this.IsMdiContainer = true;
		this.Text = "ItchyIRC v0.0.0.1";
		this.WindowState = FormWindowState.Maximized;
		this.Menu = new MainMenu();
		this.Menu.MenuItems.Add(mnuFile);
		this.Menu.MenuItems.Add(mnuOptions);
		mnuFile.MenuItems.Add(mnuConnect);
		mnuFile.MenuItems.Add(mnuExit);
		mnuOptions.MenuItems.Add(mnuPrefs);
		mnuOptions.MenuItems.Add(mnuViewMOTD);
		mnuViewMOTD.Click += new EventHandler(viewmotd);
		mnuConnect.Click += new EventHandler(connect);
		mnuPrefs.Click += new EventHandler(show_preferences);
		this.Show();
		this.Closing += new CancelEventHandler(closing_irc);
		Prefs = new Preferences(this);
	}
	
	private void show_preferences(object s,EventArgs e) {
		Prefs = new Preferences(this);
		Prefs.Show();
	}
	
	private void closing_irc(object s,CancelEventArgs e) {
		WriteLine("QUIT");
		Application.Exit();
		Running = false;
		TC.Close();
		SR.Close();
		SW.Close();
		Application.Exit();
		ExitProcess();
	}
	
	public void viewmotd(object s,EventArgs e) {
		Channel M = new Channel(this,"MOTD");
		M.send.Dispose();
		M.AddText(MOTD);
	}
	
	public void connect(object s,EventArgs e) {
		server = new Channel(this,"Server");
		string servport = InputBox.Show("Please provide a server and port:","Need a Server","irc.stealth.net 6667");
		if(servport!=null)
			servport = servport.Trim();
		if(servport==null||servport.Trim()==""||servport.IndexOf(" ")==-1) {
			if(servport.IndexOf(" ")==-1)
				MessageBox.Show("That was not good form for a server and port.");
			return;
		}
		string[] k = servport.Split(new char[] {' '});
		if(TC!=null) {
			TC.Close();
			TC = null;
		}
		string t = InputBox.Show("Please type your nick:","Need a Nick");
		if(t!=null&&t.Trim()!="")
			NICK = t;
		TC = new TcpClient(k[0],Int32.Parse(k[1]));
		SR = new StreamReader(TC.GetStream());
		SW = new StreamWriter(TC.GetStream());
		Running = true;
		server.AddText("*** Connected ***");
		Thread th = new Thread(new ThreadStart(Run));
		th.Start();
		CreateChannel += new CreateChannelEventHandler(createChannel);
	}
	
	public CreateChannelEventHandler CreateChannel;
	public delegate void CreateChannelEventHandler();
	
	private void createChannel() {
		string c = (string)channelstack.Pop();
		Channels[c] = new Channel(this,c);
	}
	
	private void Run() {
		WriteLine("user somedude789 localhost localhost : blah@nowhere.com");
		WriteLine("nick " + NICK);
		while(Running) {
			Application.DoEvents();
			string rest = "";
			string line = ReadLine();
			if(line==null)
				continue;
			line = line.Trim();
			Console.WriteLine(line);
			//TODO: parse out the delete key here...
			if(line.StartsWith("PING")) {
				WriteLine("PONG " + line.Substring(4).Trim());
				continue;
			}
			if(line.StartsWith(":"))
				rest = line.Substring(line.IndexOf(" ")).Trim();
			if(rest.StartsWith("372")) {
				MOTD += rest.Substring(rest.IndexOf(":")) + "\n";
				continue;
			}
			if(rest.StartsWith("376")) {
				server.AddText("*** Message Of The Day Received ***");
				continue;
			}
			if(rest.StartsWith("375")) {
				MOTD = "";
				continue;
			}
			if(rest.StartsWith("353")) {
				string chan = rest.Substring(rest.IndexOf("#"),rest.IndexOf(" ",rest.IndexOf("#"))-rest.IndexOf("#")).Trim();
				Channel c = (Channel)Channels[chan];
				c.ChangePeopleList(rest.Substring(rest.IndexOf(":")));
				continue;
			}
			if(rest.StartsWith("NICK")) {
				string oldnick = line.Substring(1,line.IndexOf("!")-1);
				string newnick = rest.Substring(rest.IndexOf(":")+1);
				ArrayList tochange = new ArrayList();
				ArrayList changeto = new ArrayList();
				foreach(string key in Channels.Keys) {
					Channel c = (Channel)Channels[key];
					if(c==null)
						continue;
					if(c.people.Contains(oldnick)||c.people.Contains("@"+oldnick)||c.people.Contains("+"+oldnick)||c.people.Contains("%"+oldnick)) {
						WriteLine("names " + key);
						c.AddText("*** " + oldnick + " is now known as " + newnick + " ***");
					}
					if(!key.StartsWith("#")) {
						tochange.Add(oldnick);
						changeto.Add(newnick);
					}
				}
				for(int i=0;i<tochange.Count;i++) {
					string n =(string) tochange[i];
					Channel e =(Channel) Channels[n];
					Channels[changeto[i]] = e;
					if(e==null)
						continue;
					e.Text =(string) changeto[i];
					e.channel = e.Text;
					e.AddText("*** " + n + " is now known as " + (string)changeto[i] + " ***");
				}
				continue;
			}
			if(rest.StartsWith("QUIT")) {
				foreach(string key in Channels.Keys) {
					Channel c = (Channel)Channels[key];
					if(c==null)
						continue;
					if(c.people.Contains(line.Substring(1,line.IndexOf("!")-1))||c.people.Contains("@"+line.Substring(1,line.IndexOf("!")-1))) {
						WriteLine("names " + key);				
						c.AddText("*** " + line.Substring(1,line.IndexOf("!")-1) + " has quit (" + rest.Substring(rest.IndexOf(":")+1) + ") ***");
					}
				}
				continue;
			}
			if(rest.StartsWith("PRIVMSG")) {
				string fromnick = line.Substring(1,line.IndexOf("!")-1);
				string text = rest.Substring(rest.IndexOf(":")+1);
				string chan1;
				if(rest.IndexOf("#")!=-1)
					chan1 = rest.Substring(rest.IndexOf("#"),rest.IndexOf(" ",rest.IndexOf("#"))-rest.IndexOf("#"));
				else
					chan1 = "";
				if(chan1=="") {
					if(Channels[fromnick]!=null) {
						Channel d = (Channel)Channels[fromnick];
						d.PrivMsg(fromnick,text);
						continue;
					}
					IRC.channelstack.Push(fromnick);
					this.Invoke(CreateChannel);
					Channel d1 = (Channel)Channels[fromnick];
					d1.PrivMsg(fromnick,text);
					continue;
				}
				Channel c = (Channel)Channels[chan1];
				if(c==null) {
					Console.WriteLine(line);
					continue;
				}
				c.PrivMsg(fromnick,text);
				continue;
			}
			if(rest.StartsWith("JOIN")) {
				if(line.Substring(1,line.IndexOf("!")-1)==NICK)
					continue;
				Channel c = (Channel)Channels[rest.Substring(rest.IndexOf(":")+1)];
				if(c==null) {
					MessageBox.Show("ERROR,JOIN,no channel called " + rest.Substring(rest.IndexOf(":")+1));
					continue;
				}
				IRC.WriteLine("names " + c.channel);
				c.AddText("*** " + line.Substring(1,line.IndexOf("!")-1) + " has joined us ***");
				continue;
			}
			if(rest.StartsWith("PART")) {
				if(line.Substring(1,line.IndexOf("!")-1)==NICK)
					continue;
				rest = rest.Substring(4).Trim();
				string chan1 = rest.Substring(rest.IndexOf("#"));
				if(chan1.IndexOf(":")!=-1)
					chan1 = chan1.Substring(0,chan1.IndexOf(":"));
				Channel c = (Channel)Channels[chan1.Trim()];
				if(c==null) {
					MessageBox.Show("ERROR,PART,no channel called " + chan1);
					continue;
				}
				IRC.WriteLine("names " + c.channel);
				c.AddText("*** " + line.Substring(1,line.IndexOf("!")-1) + " has left us ***");
				continue;
			}
			if(rest.StartsWith("KICK")) {
				string kicker = line.Substring(1,line.IndexOf("!")-1);
				line = line.Substring(line.IndexOf("#"));
				line = line.Substring(line.IndexOf(" ")).Trim();
				string kicked = line.Substring(0,line.IndexOf(" ")).Trim();
				string chan2 = rest.Substring(rest.IndexOf("#"));
				chan2 = chan2.Substring(0,chan2.IndexOf(" ")).Trim();
				if(kicked==NICK) {
					MessageBox.Show("You've been kicked from " + chan2 + " by " + kicker + " (" + rest.Substring(rest.IndexOf(":")+1).Trim() + ")","KICKED");
					Channel c = (Channel) Channels[chan2];
					if(c!=null)
						c.Dispose();
					continue;
				}
				Channel d =(Channel)Channels[chan2];
				if(rest.IndexOf(":")!=-1)
					kicker += " (" + rest.Substring(rest.IndexOf(":")+1).Trim() + ") ***";
				else
					kicker += " ***";
				d.AddText("*** " + kicked + " has been KICKED by " + kicker);
				IRC.WriteLine("names " + d.channel);
				continue;
			}
			server.AddText(rest);
		}
	}
	
	public static string ReadLine() {
		return SR.ReadLine();
	}
	
	public static void WriteLine(string line) {
		SW.WriteLine(line);
		SW.Flush();
	}
	
	public static void Main() {
		Application.Run(new IRC());
	}
}

public class Channel : Form {
	public RichTextBox chat = new RichTextBox();
	public RichTextBox send = new RichTextBox();
	public string channel = "";
	Form parent;
	public ArrayList people = new ArrayList();
	public ListBox lbPeople = new ListBox();
	public Font BoldFont;
	public Font UnderFont;
	private const int linecount = 27;
	
	public void AddText(string line) {
		lock(chat) {
		/*if(chat.Lines.Length==linecount) {
			chat.Text = chat.Lines[23] + "\r\n" + chat.Lines[24] + "\r\n" + chat.Lines[25] + "\r\n"
				+ chat.Lines[26] + "\r\n" + chat.Lines[27] + "\r\n";
		}*/
		char CTRL_K = (char)3;
		char CTRL_B = (char)2;
		char CTRL_U = (char)31;
		/*Console.WriteLine(line);
		foreach(char kk in line) {
			if(line.IndexOf("speeds")!=-1)
			Console.WriteLine(kk + ">>" + ((int)kk).ToString());
		}*/
		string rtf = "";
		if(line.IndexOf(CTRL_K)!=-1||line.IndexOf(CTRL_B)!=-1||line.IndexOf(CTRL_U)!=-1) {
			bool boldon = true;
			bool underon = true;
			//int insertno = 2;
			Color backcolor = Color.White;
			for(int i=0;i<line.Length;i++) {
				char c = line[i];
				try {
				if(c==CTRL_K) {
					string number = line[i+1].ToString() + line[i+2].ToString();
					if(!Char.IsNumber(number[1])) {
						number = number.Substring(0,1);
						i+=2;
					} else {
						i+=3;
					}
					if(i<=line.Length) {
						if(line[i]==',') {
							string bgnum = line[i+1].ToString() + line[i+2].ToString();
							if(!Char.IsNumber(bgnum[1])) {
								bgnum = bgnum.Substring(0,1);
								i+=2;
							} else {
								i+=3;
							}
							backcolor = GetColorFromNumber(Int32.Parse(bgnum));
						}
					}
					if(i<=line.Length&&(line[i]!=CTRL_K&&line[i]!=CTRL_U&&line[i]!=CTRL_B)) {
						chat.AppendText(line[i].ToString());
					}
					chat.SelectionStart = chat.Text.Length-1;
					chat.SelectionLength = 1;
					chat.SelectionFont = BoldFont;
					chat.SelectionColor = GetColorFromNumber(Int32.Parse(number));
					rtf = chat.SelectedRtf.Trim();
					rtf = rtf.Insert(rtf.LastIndexOf(";}"),";\\red" + backcolor.R.ToString() + "\\green" + backcolor.G.ToString() + "\\blue" + backcolor.B.ToString());
					rtf = rtf.Insert(rtf.LastIndexOf("\\"),"\\highlight2");// + insertno.ToString());
					rtf = rtf.Replace("\\highlight1","");
					//Console.WriteLine(rtf);
					chat.SelectedRtf = rtf;
				} else if(c==CTRL_B) {
					if(i<=line.Length&&(line[i]!=CTRL_K&&line[i]!=CTRL_U&&line[i]!=CTRL_B)) {
						i++;
						chat.AppendText(line[i].ToString());
					}
					//chat.SelectionStart = chat.Text.Length-1;
					//chat.SelectionLength = 1;
					if(boldon)
						chat.SelectionFont = BoldFont;
					else {
						//chat.SelectionStart = chat.Text.Length;
						//chat.SelectionLength = 0;
						chat.SelectionFont = chat.Font;
					}
					boldon = !boldon;
				} else if(c==CTRL_U) {
					if(i<=line.Length&&(line[i]!=CTRL_K&&line[i]!=CTRL_U&&line[i]!=CTRL_B)) {
						i++;
						chat.AppendText(line[i].ToString());
					}
					//chat.SelectionStart = chat.Text.Length-1;
					//chat.SelectionLength = 1;
					if(underon)
						chat.SelectionFont = UnderFont;
					else {
						//chat.SelectionStart = chat.Text.Length;
						//chat.SelectionLength = 0;
						chat.SelectionFont = chat.Font;
					}
					underon = !underon;
				} else {
					chat.AppendText(line[i].ToString());
				}
				} catch(Exception e44) { e44=e44; }
			}
			chat.AppendText("\r\n");
		} else {
			chat.AppendText(line + "\r\n");
		}
		chat.SelectionStart = chat.Text.Length - line.Length;
		chat.SelectionLength = line.Length;
		chat.ScrollToCaret();
		//chat.SelectionLength = 0;
	}
	}
	
	public Color GetColorFromNumber(int n) {
		switch(n) {
			case 0:
				return Color.White;
			case 1:
				return Color.Black;
			case 2:
				return Color.DarkBlue;  //blue(ish)
			case 3:
				return Color.ForestGreen; //green
			case 4:
				return Color.Red; //red
			case 5:
				return Color.Brown;
			case 6:
				return Color.DarkMagenta;
			case 7:
				return Color.Salmon; //not sure.. Peach??
			case 8:
				return Color.Yellow;
			case 9:
				return Color.LightGreen; // lighter green
			case 10:	
				return Color.DarkSlateBlue; // no Color.DarkAqua...
			case 11:
				return Color.Aqua;
			case 12:
				return Color.Blue;
			case 13:
				return Color.Magenta;
			case 14:
				return Color.Gray;
			case 15:
				return Color.DarkGray;
			default:
				return Color.SlateGray;
		}
	}
	
	public Channel(Form p,string c) {
		parent = p;
		this.MdiParent = p;
		this.WindowState = FormWindowState.Maximized;
		channel = c;
		this.Text = c;
		BoldFont = new Font(chat.Font.Name,chat.Font.Size,FontStyle.Bold);
		UnderFont = new Font(chat.Font.Name,chat.Font.Size+2,FontStyle.Underline);
		chat.Font = new Font(chat.Font.Name,chat.Font.Size+2,chat.Font.Style);
		chat.DetectUrls = true;
		chat.Dock = DockStyle.Fill;
		chat.LinkClicked += new LinkClickedEventHandler(link_clicked);
		send.Dock = DockStyle.Bottom;
		lbPeople.Dock = DockStyle.Left;
		this.Controls.Add(chat);
		this.Controls.Add(send);
		this.Closing += new CancelEventHandler(closed_part);
		if(c.StartsWith("#"))
			this.Controls.Add(lbPeople);
		this.Show();
		send.KeyDown += new KeyEventHandler(key_down);
	}
	
	private void link_clicked(object s,LinkClickedEventArgs e) {
		System.Diagnostics.Process.Start(e.LinkText);
	}
	
	private void closed_part(object s,CancelEventArgs e) {
		if(channel.StartsWith("#"))
			IRC.WriteLine("PART " + this.channel);
	}
	
	public void ChangePeopleList(string names) {
		names = names.Substring(1).Trim();
		string[] k = names.Split(new char[]{' '});
		people.Clear();
		foreach(string n in k)
			people.Add(n);
		people.Sort();
		k = (string[])people.ToArray(typeof(string));
		lbPeople.Items.Clear();
		lbPeople.Items.AddRange(k);
	}
	
	private void key_down(object s,KeyEventArgs e) {
		if(e.KeyCode==Keys.Enter) {
			string t = send.Text.Trim();
			send.Clear();
			send.SelectionStart = 0;
			SendText(ParseForCommands(t));
			send.Text = "";
			send.Clear();
		}
	}
	
	private string ParseForCommands(string text) {
		text = text.Trim();
		string com, args;
		string[] alist;
		if(text.IndexOf(" ")!=-1) {
			com = text.Substring(0,text.IndexOf(" ")).Trim();
			args = text.Substring(text.IndexOf(" ")).Trim();
			alist = args.Split(new char[] {' '});
		} else {
			com = text;
			alist = new string[] {"","",""};
			args = "";
		}
		if(!Preferences.commands.ContainsKey(com))
			return text;
		string todo =(string) Preferences.commands[com] + " ";
		todo = todo.Replace(" # "," " + channel + " ");
		todo = todo.Replace(" $ARGS "," " + args + " ");
		todo = todo.Replace(" $1 "," " + alist[0] + " ");
		if(alist.Length>1)
			todo = todo.Replace(" $2 "," " + alist[1] + " ");
		if(alist.Length>2)
			todo = todo.Replace(" $3 "," " + alist[2] + " ");
		return todo;
	}
	
	private void SendText(string text) {
		text = text.Trim();
		text = text.Replace("/u",((char)31).ToString());
		text = text.Replace("/b",((char)2).ToString());
		text = text.Replace("/color",((char)3).ToString());
		if(text.StartsWith("/")) {
			if(text.StartsWith("/kick ")) {
				text = text.Substring(5).Trim();
				IRC.WriteLine("KICK " + channel + " " + text.Replace(" "," :"));
				return;
			}
			if(text.StartsWith("/join")) {
				string c = text.Substring(5).Trim();
				IRC.channelstack.Push(c);
				parent.Invoke(((IRC)parent).CreateChannel);
			}
			if(text.StartsWith("/nick "))
				IRC.NICK = text.Substring(5).Trim();
			text = text.Substring(1);
			IRC.WriteLine(text);
			return;
		}
		if(people.Contains("@" + IRC.NICK)&&channel!="Server")
			AddText("<@" + IRC.NICK + "> " + text);
		else
			AddText("<" + IRC.NICK + "> " + text);
		IRC.WriteLine("privmsg " + channel + " :" + text.Trim());
	}
	
	public void PrivMsg(string nick,string text) {
		text = text.Trim();
		nick = nick.Trim();
		/* Found to be unnecessary
		foreach(string k in people) {
			if(k.StartsWith("+")&&k.Substring(1)==nick) {
				AddText("<" + k + "> " + text);
				return;
			}
			if(k.StartsWith("%")&&k.Substring(1)==nick) {
				AddText("<" + k + "> " + text);
				return;
			}
			if(k.StartsWith("@")&&k.Substring(1)==nick) {
				AddText("<" + k + "> " + text);
				return;
			}
			if(k==nick) {
				AddText("<" + k + "> " + text);
				return;
			}
		}*/
		AddText("<" + nick + "> " + text);
	}
}

public class Preferences : Form {
	
	public static Hashtable commands = new Hashtable();
	Form parent;
	RichTextBox tbCommands = new RichTextBox();
	TextBox tbNewCommand = new TextBox();
	TextBox tbCommandDoes = new TextBox();
	Button btnAddCommand = new Button();
	
	public Preferences(Form p) {
		this.MdiParent = p;
		parent = p;
		bool command = false;
		if(!File.Exists("prefs.ini")) {
			File.CreateText("prefs.ini").Close();
		} else {
			StreamReader SR = new StreamReader("prefs.ini");
			while(SR.Peek()!=-1) {
				string line = SR.ReadLine();
				if(line==null||line.Trim()=="")
					continue;
				if(line=="Commands:") {
					command = true;
					continue;
				}
				if(line=="/Commands") {
					command = false;
					continue;
				}
				if(command) {
					commands[line] = SR.ReadLine();
					continue;
				}
			}
			SR.Close();
		}
		this.Text = "Preferences";
		this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
		this.MaximizeBox = false;
		this.WindowState = FormWindowState.Normal;
		this.Closing += new CancelEventHandler(closeprefs);
		tbCommands.Dock = DockStyle.Top;
		tbCommands.WordWrap = false;
		tbNewCommand.Location = new Point(0,tbCommands.Height+2);
		tbCommandDoes.Location = new Point(tbNewCommand.Width+2,tbCommands.Height+2);
		tbCommandDoes.Size = new Size(this.Width-tbCommandDoes.Width-11,tbCommandDoes.Height);
		btnAddCommand.Location = new Point(10,tbCommands.Height+tbNewCommand.Height+2);
		btnAddCommand.Size = new Size(this.Width-20,btnAddCommand.Height);
		btnAddCommand.Text = "Add New Command";
		foreach(string key in commands.Keys) {
			tbCommands.Text += key + " = " +(string) commands[key] + "\r\n";
		}
		this.Controls.Add(tbCommands);
		this.Controls.Add(tbNewCommand);
		this.Controls.Add(tbCommandDoes);
		this.Controls.Add(btnAddCommand);
		btnAddCommand.Click += new EventHandler(add_command);
	}
	
	private void closeprefs(object s,CancelEventArgs e) {
		StreamWriter SW = new StreamWriter("prefs.ini");
		SW.WriteLine("Commands:");
		foreach(string key in commands.Keys) {
			SW.WriteLine(key);
			SW.WriteLine((string) commands[key]);
			SW.Flush();
		}
		SW.WriteLine("/Commands");
		SW.Flush();
		SW.Close();
	}
	
	private void add_command(object s,EventArgs e) {
		commands[tbNewCommand.Text.Clone()] = tbCommandDoes.Text.Clone();
		tbCommands.Text = "";
		foreach(string key in commands.Keys) {
			tbCommands.Text += key + " = " +(string) commands[key] + "\r\n";
		}
	}
	
}
