using System;
using System.Windows.Forms;
using System.Drawing;

public class InputBox : Form {

	private Label internText = new Label();
	internal protected TextBox tb1 = new TextBox();
	private Button OK = new Button();
	private Button cancl = new Button();
	
	private InputBox(string text, string title) {
		this.Text = title;
		internText.Text = text;
		this.Size = new Size(450,150);
		internText.Size = this.Size;
		internText.Location = new Point(10,10);
		tb1.Multiline = true;
		tb1.KeyUp += new KeyEventHandler(key_up);
		tb1.Location = new Point(10,60);
		tb1.Size = new Size(300, tb1.Size.Height);
		this.ShowInTaskbar = false;
		this.FormBorderStyle = FormBorderStyle.FixedSingle;
		this.MaximizeBox = false;
		this.MinimizeBox = false;
		OK.Text = "OK";
		cancl.Text = "Cancel";
		OK.Location = new Point(320,30);
		cancl.Location = new Point(320,34+OK.Size.Height);
		this.CancelButton = cancl;
		this.AcceptButton = OK;
		OK.DialogResult = DialogResult.OK;
		this.Controls.Add(tb1);
		this.Controls.Add(OK);
		this.Controls.Add(cancl);
		this.Controls.Add(internText);
	}

	private void key_up(object s,KeyEventArgs e) {
		if(e.KeyCode==Keys.Enter) {
			tb1.Text = tb1.Text.Trim();
			OK.PerformClick();
		}
	}

	public static string Show(string text,string title) {
		InputBox IB = new InputBox(text, title);
		IB.ShowDialog();
		if(IB.DialogResult==DialogResult.Cancel)
			return "";
		else
			return IB.tb1.Text;
	}
	
	public static string Show(string text,string title,string deft) {
		InputBox IB = new InputBox(text, title);
		IB.tb1.Text = deft;
		IB.ShowDialog();
		if(IB.DialogResult==DialogResult.Cancel)
			return "";
		else
			return IB.tb1.Text;
	}

}//end of class InputBox
