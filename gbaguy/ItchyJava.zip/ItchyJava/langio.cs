using System;
using IO = System.IO;
using Coll = System.Collections;
using SOCK = System.Net.Sockets;
using NET = System.Net;

/* This file contains the implementation of java.lang, and java.io 
 * Originally written by Mike H (aka GbaGuy, ASMGuy, generally *Guy) vbnetprogramer@hotmail.com
 * http://k2pts.home.comcast.net/gbaguy/
 * This file v0.0.0.1
 * ---
 * All classes will be implemented on release of v0.1.0.0, not all classes do exactly what they
 * should (many buffered classes don't buffer...), and many methods that do a test
 * just contain the line "return false;"...
 * ---
 * This may get released as GPL if it ends up being any good...
 * DO NOT DISTRIBUTE!
*/

namespace Itchy {
	public class ItchySocketImpl : java.net.SocketImpl {
		SOCK.Socket sock;
		public ItchySocketImpl() {}
		public override void Create(bool stream) {
			// stream not used, will always create a stream socket
			sock = new SOCK.Socket(SOCK.AddressFamily.InterNetwork,SOCK.SocketType.Stream,SOCK.ProtocolType.Tcp);
		}
		public override void Connect(string host,int port) {
			if(sock==null)
				Create(true);
			NET.IPAddress IP = NET.IPAddress.Parse(java.net.InetAddress.GetByName(host).ToString());
			NET.IPEndPoint IPEP = new NET.IPEndPoint(IP,port);
			sock.Connect(IPEP);
		}
		public override void Connect(java.net.InetAddress host,int port) {
			if(sock==null)
				Create(true);
			NET.IPAddress IP = NET.IPAddress.Parse(host.ToString());
			NET.IPEndPoint IPEP = new NET.IPEndPoint(IP,port);
			sock.Connect(IPEP);
		}
		public override void Bind(java.net.InetAddress host,int port) {
			NET.IPAddress IP = NET.IPAddress.Parse(host.ToString());
			NET.IPEndPoint IPEP = new NET.IPEndPoint(IP,port);
			sock.Bind(IPEP);
		}
		public override void Listen(int backlog) {sock.Listen(backlog);}
		public override void Accept(java.net.SocketImpl s) {
			SOCK.Socket so = sock.Accept();
			ItchySocketImpl ISI = new ItchySocketImpl();
			ISI.sock = so;
			s =(java.net.SocketImpl) ISI;
		}
		public override void Close() { sock.Close(); }
		public override int Available() {return sock.Available;}
		public override java.io.OutputStream GetOutputStream() {return (java.io.OutputStream) new ItchyOutputStream(new SOCK.NetworkStream(sock));}
		public override java.io.InputStream GetInputStream() {return (java.io.InputStream) new ItchyInputStream(new SOCK.NetworkStream(sock));}
	}
	public class ItchyOutputStream : java.io.OutputStream {
		IO.Stream str;
		public ItchyOutputStream(IO.Stream s) {str = s;}
		public override void Write(int b) {str.WriteByte((byte)b);}
		public override void Flush() { str.Flush(); }
		public override void Close() { str.Close(); }
	}
	public class ItchyInputStream : java.io.InputStream {
		IO.Stream str;
		public ItchyInputStream(IO.Stream s) {str = s;}
		public override int Read() { return str.ReadByte(); }
	}
	public class EnumHelp : java.util.Enumeration {
		System.Collections.ArrayList al = new System.Collections.ArrayList();
		int pos = 0;
		public EnumHelp(System.Collections.ICollection i) {
			System.Collections.IEnumerator ie = i.GetEnumerator();	
			for(int x=0;x<i.Count;x++) {
				al.Add(ie.Current);
				ie.MoveNext();
			}
		}
		public bool HasMoreElements() {
			if(pos==al.Count) return false;
			return true;
		}
		public object NextElement() {
			return al[pos++];
		}
	}
	public class ConsoleInputStream : java.io.InputStream {
		public ConsoleInputStream() {}
		public override int Read() {
			return Console.Read();
		}
	}
}

namespace java.lang {
	public abstract class Number {
		public Number() {}
		public abstract byte ByteValue();
		public abstract double DoubleValue();
		public abstract float FloatValue();
		public abstract int IntValue();
		public abstract long LongValue();
		public abstract short ShortValue();
	}
	public class Integer : Number {
		int i = 0;
		public Integer(string n) {i = Int32.Parse(n);}
		public Integer(int d) {i=d;}
		public const int MAX_VALUE = 2147483647;
		public const int MIN_VALUE = -2147483648;
		public static Integer Decode(string nm) {return new Integer(Int32.Parse(nm));}
		public static Integer GetInteger(string nm) {
			//to be implemented
			return new Integer(0);
		}
		public static Integer GetInteger(string nm,int val) {
			//to be implemented
			return new Integer(val);
		}
		public static Integer GetInteger(string nm,Integer val) {
			//to be implemented
			return val;
		}
		public override byte ByteValue() {return(byte)i;}
		public override int IntValue() {return i;}
		public override long LongValue() {return(long)i;}
		public override float FloatValue() {return(float)i;}
		public override double DoubleValue() {return(double)i;}
		public override short ShortValue() {return(short)i;}
		public static int ParseInt(string nm) {return Int32.Parse(nm);}
		//to be implemented: public static int ParseInt(string nm,int radix);
		//to be implemented: the rest of class Integer!
	}
	public class System {
		public static java.io.PrintStream Out = new java.io.PrintStream(Console.Out); //(PrintStream) new VM.ConsoleOutputStream();
		public static java.io.InputStream In = (java.io.InputStream) new Itchy.ConsoleInputStream();
		public static java.io.PrintStream Err = new java.io.PrintStream(Console.Error);
	}
	public class StringBuffer {
		protected string buf = "";
		public StringBuffer() {}
		public StringBuffer(int size) {size=size;}
		public StringBuffer(string init) {buf=init;}
		public StringBuffer Append(bool b) {buf+=b.ToString(); return this;}
		public StringBuffer Append(char c) {buf+=c.ToString(); return this;}
		public StringBuffer Append(object o) {buf+=o.ToString(); return this;}
		public StringBuffer Append(string s) {buf+=s; return this;}
		public StringBuffer Append(int i) {buf+=i.ToString(); return this;}
		public StringBuffer Append(long l) {buf+=l.ToString(); return this;}
		public StringBuffer Append(float f) {buf+=f.ToString(); return this;}
		public StringBuffer Append(double d) {buf+=d.ToString(); return this;}
		public StringBuffer Append(char[] c) {Append(c,0,c.Length); return this;}
		public StringBuffer Append(char[] c,int off,int len) {
			for(int i=off;i<len;i++)
				buf += c[i].ToString();
			 return this;
		}
		public void SetCharAt(int index,char ch) {
			char[] d = buf.ToCharArray();
			d[index] = ch;
			buf = "";
			for(int i=0;i<d.Length;i++)
				buf += d[i].ToString();
		}
		public void GetChars(int srcBegin,int srcEnd,char[] dst,int dstBegin) {
			for(int i=srcBegin;i<srcEnd;i++)
				dst[dstBegin+i] = buf[i];
		}
		public char CharAt(int index) {return buf[index];}
		public void SetLength(int newLength) {
			char[] d = new char[newLength];
			buf.CopyTo(0,d,0,d.Length);
			buf = "";
			for(int i=0;i<d.Length;i++)
				buf += d[i].ToString();
		}
		public void EnsureCapacity(int minimumCapacity) {
			if(minimumCapacity<=0)
				return;
			char[] d = new char[minimumCapacity];
			for(int i=0;i<d.Length;i++)
				buf += d[i].ToString();
		}
		public int Capacity() {return buf.Length;}
		public int Length() {return buf.Length;}
		public StringBuffer Insert(int offset,object obj) {buf.Insert(offset,obj.ToString()); return this;}
		public StringBuffer Insert(int offset,string str) {buf.Insert(offset,str); return this;}
		public StringBuffer insert(int offset,char[] str) {
			string srt = "";
			for(int i=0;i<str.Length;i++)
				srt += str[i].ToString();
			buf.Insert(offset,srt);
			return this;
		}
		public StringBuffer Insert(int offset,bool b) {buf.Insert(offset,b.ToString());	return this;}
		public StringBuffer Insert(int offset,char c) {buf.Insert(offset,c.ToString());	return this;}
		public StringBuffer Insert(int offset,int i) {buf.Insert(offset,i.ToString()); return this;}
		public StringBuffer Insert(int offset,long l) {buf.Insert(offset,l.ToString());	return this;}
		public StringBuffer Insert(int offset,float f) {buf.Insert(offset,f.ToString()); return this;}
		public StringBuffer Insert(int offset,double d) {buf.Insert(offset,d.ToString()); return this;}
		public override string ToString() {return buf;}
		public StringBuffer Reverse() {
			char[] d = buf.ToCharArray();
			buf = "";
			for(int i=d.Length-1;i>=0;i--) {
				buf += d[i].ToString();
			}
			return this;
		}
	}
}

namespace java.io {
	//interfaces
	public interface FilenameFilter {
		bool Accept(File dir,string name);
	}
	//classes
	
	public class FileDescriptor {
		//public const FileDescriptor Out,Err,In .
		internal string Filename = ""; // there has to be one, otherwise I don't get how to use this class...
		public FileDescriptor() {}
		public void Sync() {}
		public bool Valid() {
			if(IO.File.Exists(Filename))
				return true;
			return false;
		}
	}
	public class InputStreamReader : Reader {
		protected InputStream In;
		string Encoding = "default";
		public InputStreamReader(InputStream i) {In = i;}
		public InputStreamReader(InputStream i,string en) {In=i;Encoding=en;}
		public string GetEncoding() {return Encoding;}
		public override int Read() {return In.Read();}
		public override void Close() {In.Close();}
		public override int Read(char[] buf,int off,int len) {
			int i=0;
			for(i=off;i<len;i++)
				buf[i] =(char) Read();
			return i-off;
		}
		//public bool Ready() {return false;} , inherits a method that so far will do the same thing
	}
	public class FileOutputStream : OutputStream {
		IO.StreamWriter Sw;
		IO.BinaryWriter Bw;
		public FileOutputStream(string filename) {
			Sw = new IO.StreamWriter(filename);
			Bw = new IO.BinaryWriter(Sw.BaseStream);
		}
		public FileOutputStream(File file) {Sw = new IO.StreamWriter(file.GetPath());}
		public FileOutputStream(string filename,bool append) {
			if(append)
				Sw = IO.File.AppendText(filename);
			else
				Sw = new IO.StreamWriter(filename);
			Bw = new IO.BinaryWriter(Sw.BaseStream);
		}
		public FileOutputStream(FileDescriptor fdObj) {
			Sw = new IO.StreamWriter(fdObj.Filename);
			Bw = new IO.BinaryWriter(Sw.BaseStream);
		}
		public override void Flush() {Bw.Flush(); Sw.Flush();}
		public override void Close() {Bw.Flush(); Sw.Flush(); Bw.Close(); Sw.Close();}
		public override void Write(int b) {Bw.Write((byte)b); Sw.Flush();}
	}
	public class FileInputStream : InputStream {
		IO.StreamReader sr;
		public FileInputStream(string filename) {sr = new IO.StreamReader(filename);}
		public FileInputStream(java.io.File file) {
			if(!file.Exists()) {
				// do something here (should be FileNotFoundException
			}
			sr = new IO.StreamReader(file.GetPath());
		}
		public FileInputStream(FileDescriptor fdObj) {sr = new IO.StreamReader(fdObj.Filename);}
		public override int Read() {return sr.Read();}
		public new int Read(byte[] b) {return Read(b,0,b.Length);}
		public new int Read(byte[] b,int off,int len) {
			int i = 0;
			for(i=off;i<len;i++)
				b[i] =(byte) Read();
			return i;
		}
		public new long Skip(long n) {
			int i = 0;
			for(i=0;i<n;i++)
				Read();
			return i;
		}
		public new int Available() {
			IO.Stream s = sr.BaseStream;
			return (int)(s.Length - s.Position);
		}
		public new void Close() {sr.Close();}
		public FileDescriptor GetFD() {return null;} // wtf do these FileDescriptors do?
		//~FileInputStream() {sr.Close();} causes problems
	}
	public class File {
		// should implement java.io.Serializable
		public const string Separator = @"\";
		public const char SeparatorChar = '\\';
		public const string PathSeparator = ";";
		public const char PathSeparatorChar = ';';
		private string filename = "";
		public File(string FileName) {filename = FileName;}
		public File(string path,string name) {filename = path + Separator + name;}
		public File(File dir,string name) {
			if(dir==null)
				filename = IO.Directory.GetCurrentDirectory() + Separator + name;
			else
				filename = dir.GetPath() + Separator + name;
		}
		public string GetName() {return filename.Substring(filename.LastIndexOf(Separator)+1);}
		public string GetPath() {return filename;}
		public string GetAbsolutePath() {return filename;}
		public string GetCanonicalPath() {return filename;}
		public string GetParent() {return filename.Substring(0,filename.LastIndexOf(Separator,filename.LastIndexOf(Separator)-1));}
		public bool Exists() {return (System.IO.File.Exists(filename)||System.IO.Directory.Exists(filename));}
		public bool CanWrite() {return true;}
		public bool CanRead() {return true;}
		public bool IsFile() {return System.IO.File.Exists(filename);}
		public bool IsDirectory() {return System.IO.File.Exists(filename);}
		public bool IsAbsolute() {return filename[1]==':'||filename.StartsWith(@"\");}
		public long LastModified() {return System.IO.File.GetLastAccessTime(filename).ToFileTime();}
		public long Length() {
			System.IO.FileInfo FI = new IO.FileInfo(filename);
			return FI.Length;
		}
		public bool Mkdir() {
			IO.DirectoryInfo DI = System.IO.Directory.CreateDirectory(filename);
			if(DI==null||!DI.Exists)
				return false;
			return true;
		}
		public bool RenameTo(File dest) {
			// may not work correctly
			System.IO.File.Move(filename,dest.GetPath());
			System.IO.Directory.Move(filename,dest.GetPath());
			return true;
		}
		public bool Mkdirs() {return false;} // not done yet.
		public string[] List() {
			if(!System.IO.Directory.Exists(filename)) {
				return null;
			}
			return IO.Directory.GetFiles(filename);
		}
		public string[] List(FilenameFilter filter) {
			return null;
		}
		public bool Delete() {
			if(!System.IO.File.Exists(filename)&&!System.IO.Directory.Exists(filename))
				return false;
			if(System.IO.File.Exists(filename)) {
				IO.File.Delete(filename);
				return true;
			}
			IO.Directory.Delete(filename);
			return true;
		}
		public int HashCode() {
			return filename.GetHashCode(); //that can't be right, can it?
		}
		public override bool Equals(object obj) {
			if(!(obj is java.io.File))
				return false;
			File ddf =(File) obj;
			if(ddf.GetPath()==filename)
				return true;
			return false;
		}
		public override int GetHashCode() {return base.GetHashCode();}
		public override string ToString() {
			return filename;
		}
	}
	public class ByteArrayOutputStream : OutputStream {
		protected byte[] buf;
		protected int count = 0;
		public ByteArrayOutputStream() {buf = new byte[512];}
		public ByteArrayOutputStream(int size) {buf = new byte[size];}
		public override void Write(int b) {
			if(count>buf.Length) {
				byte[] d = new byte[buf.Length*2];
				buf.CopyTo(d,0);
				buf = d;
			}
			count++;
			buf[count-1] =(byte) b;
		}
		public new void Write(byte[] b,int off,int len) {
			for(int i=off;i<len;i++)
				Write((int)b[i]);
		}
		public void WriteTo(OutputStream Out) {
			Out.Write(buf,0,count);
		}
		public void Reset() {count=0;}
		public byte[] ToByteArray() {
			byte[] s = new byte[count];
			for(int i=0;i<count;i++)
				s[i] = buf[i];
			return s;
		}
		public int Size() {return count;}
		public override string ToString() {
			string a = "";
			for(int i=0;i<count;i++)
				a += ((char)buf[i]).ToString();
			return a;
		}
		public string ToString(String enc) {
			enc = enc; //not used yet.
			return ToString();
		}
		public override void Flush() {}
		public override void Close() {}
	}
	public class ByteArrayInputStream : InputStream {
		protected byte[] buf;
		protected int count;
		protected int pos;
		protected int mark;
		public ByteArrayInputStream(byte[] b) {
			buf = b;
			pos = 0;
			count = buf.Length;
		}
		public ByteArrayInputStream(byte[] b,int off,int len) {
			buf = b;
			count = len;
			pos = off;
		}
		public override int Read() {
			if(pos>count)
				return -1;
			return (int) buf[pos++];
		}
		// not sure exactly what to return below...
		public new int Read(byte[] b,int off,int len) {
			if(pos>count)
				return -1;
			int c = 0;
			for(int i=off;i<len;i++) {
				if(pos>count)
					return c;
				c++;
				b[i] = buf[pos++];
			}
			return c;
		}
		public new long Skip(long n) {
			for(int i=0;i<n;i++)
				Read();
			return n;
		}
		public new int Available() {
			return count - pos;
		}
		public new bool MarkSupported() {return true;}
		public new void Mark(int r) {mark=r;}
		public new void Reset() { pos = mark; }
	}
	public class BufferedReader : Reader {
		//needs to be rewritten to actually do buffering...
		protected Reader In;
		public BufferedReader(Reader i) {In = i;}
		public BufferedReader(Reader i,int s) {
			In = i;
			s = s; //not used yet.
		}
		public override int Read() {
			return In.Read();
		}
		public override void Close() {In.Close();}
		public override int Read(char[] cbuf,int off,int len) {
			return In.Read(cbuf,off,len);
		}
		public string ReadLine() {
			string a = "";
			char c = ' ';
			do {
				c =(char) In.Read();
				a += c.ToString();
			} while(c!='\r'&&c!='\n');
			In.Read();
			return a.Substring(0,a.Length-1);
		}
		public new long Skip(long n) {
			return In.Skip(n);
		}
		public new bool Ready() {
			return In.Ready();
		}
		public new bool MarkSupported() {return false;} // not yet.
		public new void Mark(int r) {} // not yet.
		public new void Reset() {In.Reset();}
	}
	public class BufferedOutputStream : FilterOutputStream {
		new protected OutputStream Out;
		public BufferedOutputStream(OutputStream o) : base(o) {
			Out = o;
		}
		public BufferedOutputStream(OutputStream o,int s) : base(o) {
			Out = o;
			s = s; // not used in this implementation.
		}
		public new void Write(int b) {Out.Write(b);}
		public new void Write(byte[] b,int off,int len) {Out.Write(b,off,len);}
		public new void Flush() {Out.Flush();}
	}
	public class BufferedInputStream : FilterInputStream {
		new protected InputStream In;
		public BufferedInputStream(InputStream i) : base(i) {
			In = i;
		}
		public BufferedInputStream(InputStream i,int s) : base(i) {
			In = i;
			s = s; // not used in this implementation.
		}
		public new int Read() {
			return In.Read();
		}
		public new int Read(byte[] b,int off,int len) {
			return In.Read(b,off,len);
		}
		public new long Skip(long n) {
			return In.Skip(n);
		}
		public new int Available() {
			return In.Available();
		}
		public new void Mark(int r) {}
		public new void Reset() {In.Reset();}
		public new bool MarkSupported() {return In.MarkSupported();}
	}
	public class FilterInputStream : InputStream {
		protected InputStream In;
		public FilterInputStream(InputStream i) {In = i;}
		public override int Read() {return In.Read();}
		public new int Read(byte[] b) {return In.Read(b);}
		public new int Read(byte[] b,int off,int len) {return In.Read(b,off,len);}
		public new long Skip(long n) {return In.Skip(n);}
		public new int Available() {return In.Available();}
		public new void Close() {In.Close();}
		public new void Mark(int a) {In.Mark(a);}
		public new void Reset() {In.Reset();}
		public new bool MarkSupported() {return In.MarkSupported();}
	}
	public class BufferedWriter : Writer {
		Writer Out;
		public BufferedWriter(Writer o) : base(o) {
			Out = o;
		}
		public BufferedWriter(Writer o,int sz) : base(o) {
			Out = o;
			sz = sz; //unused in this implementation.
		}
		public void newLine() {
			Write((int)'\r');
			Write((int)'\n');
		}
		public new void Write(int c) {
			Out.Write((char)c);
		}
		public override void Close() {Out.Close();}
		public override void Flush() {Out.Flush();}
		public override void Write(char[] cbuf,int off,int len) {
			for(int i=off;i<len;i++)
				Write((int)cbuf[i]);
		}
		public new void Write(string c,int off,int len) {
			Write(c.ToCharArray(),off,len);
		}
	}
	public abstract class InputStream {
		public InputStream() {}
		public int Available() {return 0;}
		public void Reset() {}
		public abstract int Read();
		public int Read(byte[] b) {
			return Read(b,0,b.Length);
		}
		public int Read(byte[] b,int off,int len) {
			int count = 0;
			for(int i=off;i<len;i++) {
				b[i] =(byte) Read();
				count++;	
			}
			return count;
		}
		public long Skip(long n) {
			//should count actual number
			byte[] b = new byte[n];
			for(int i=0;i<n;i++) {
				b[i] =(byte) Read();
			}
			return n;
		}
		public void Mark(int pos) {}
		public bool MarkSupported() {return false;}
		public void Close() {}
	}
	public abstract class Writer {
		protected object Lock;
		protected Writer() {
			Lock = this;
		}
		protected Writer(object l) {
			Lock = l;
		}
		public abstract void Close();
		public abstract void Flush();
		public abstract void Write(char[] cbuf, int off, int len);
		public void Write(int c) {
			lock(Lock) {
				Write(new char[] {(char)c},0,1);
			}
		}
		public void Write(char[] cbuf) {
			lock(Lock) {
				Write(cbuf,0,cbuf.Length);
			}
		}
		public void Write(string s) {
			lock(Lock) {
				Write(s.ToCharArray(),0,s.Length);
			}
		}
		public void Write(string s,int off,int len) {
			lock(Lock) {
				Write(s.ToCharArray(),off,len);
			}
		}
	}
	public abstract class Reader {
		object Lock;
		public Reader() {
			Lock = this;
		}
		public Reader(object l) {
			Lock = l;
		}
		public abstract void Close();
		public abstract int Read();
		public int Read(char[] cbuf) {
			for(int i=0;i<cbuf.Length;i++)
				cbuf[i] =(char) Read();
			return cbuf.Length;
		}
		public abstract int Read(char[] cbuf,int off,int len);
		public long Skip(long n) {
			for(int i=0;i<n;i++)
				Read();
			return n;
		}
		public bool Ready() {return false;}
		public bool MarkSupported() {return false;}
		public void Mark(int readAheadLimit) {}
		public void Reset() {}
	}
	public abstract class OutputStream {
		public abstract void Write(int b);
		public void Write(byte[] b) {
			for(int i=0;i<b.Length;i++)
				Write((int)b[i]);
		}
		public void Write(byte[] b,int off,int len) {
			for(int i=off;i<len;i++)
				Write((int)b[i]);
		}
		public abstract void Flush();
		public abstract void Close();
	}
	public class FilterOutputStream : OutputStream {
		protected OutputStream Out;
		public FilterOutputStream(OutputStream o) {
			Out = o;
		}
		public override void Write(int b) {
			Out.Write(b);
		}
		public new void Write(byte[] b) {
			Write(b,0,b.Length);
		}
		public new void Write(byte[] b,int off,int len) {
			for(int i=off;i<len;i++)
				Write((int)b[i]);
		}
		public override void Flush() {
			Out.Flush();
		}
		public override void Close() {
			Out.Flush();
			Out.Close();
		}
	}
	public class PrintStream : FilterOutputStream {
		IO.TextWriter TW;
		new protected OutputStream Out;
		bool AutoFlush = false;
		public PrintStream(System.IO.TextWriter o) : base(null) {
			TW = o;
		}
		public PrintStream(OutputStream o) : base(o) {
			Out = o;
		}
		public PrintStream(OutputStream o,bool autoFlush) : base(o) {
			Out = o;
			AutoFlush = autoFlush;
		}
		public bool CheckError() {
			return false;
		}
		public new void Flush() {
			if(TW!=null)
				TW.Flush();
			else
				Out.Flush();
		}
		public new void Close() {
			if(TW!=null)
				TW.Close();
			else
				Out.Close();
		}
		public override void Write(int b) {
			if(TW!=null)
				TW.Write((char)b);
			else
				Out.Write(b);
		}
		public void Print(bool b) {
			string a = b.ToString();
			for(int i=0;i<a.Length;i++)
				Write((int)a[i]);
		}
		public void Print(int i) {
			string a = i.ToString();
			for(int x=0;x<a.Length;x++)
				Write((int)a[x]);
		}
		public void Print(long l) {
			string a = l.ToString();
			for(int i=0;i<a.Length;i++)
				Write((int)a[i]);
		}
		public void Print(float f) {
			string a = f.ToString();
			for(int i=0;i<a.Length;i++)
				Write((int)a[i]);
		}
		public void Print(double d) {
			string a = d.ToString();
			for(int i=0;i<a.Length;i++)
				Write((int)a[i]);
		}
		public void Print(char[] c) {
			for(int i=0;i<c.Length;i++)
				Write((int)c[i]);
		}
		public void Print(string s) {
			if(s==null)
				s = "null";
			for(int i=0;i<s.Length;i++)
				Write((int)s[i]);
		}
		public void Print(object o) {
			string s;
			if(o==null)
				s = "null";
			else
				s = o.ToString();
			for(int i=0;i<s.Length;i++)
				Write((int)s[i]);
		}
		public void Println() {
			Print("\r");
			Print("\n");
		}
		public void Println(bool x) {
			Print(x);
			Println();
		}
		public void Println(char x) {
			Print(x);
			Println();
		}
		public void Println(int x) {
			Print(x);
			Println();
		}
		public void Println(long x) {
			Print(x);
			Println();
		}
		public void Println(float x) {
			Print(x);
			Println();
		}
		public void Println(double x) {
			Print(x);
			Println();
		}
		public void Println(char[] x) {
			Print(x);
			Println();
		}
		public void Println(string x) {
			Print(x);
			Println();
		}
		public void Println(object x) {
			Print(x);
			Println();
		}
	}
}
