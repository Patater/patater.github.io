
class Factorial {

public static void main(String[] args) {
	int a = 4;
	int b = a;
	int res = 1;
	while(a > 1) {
		res = res * a;
		a = a - 1;
	}
	System.out.println("The factorial of " + b + " is " + res);
}

}