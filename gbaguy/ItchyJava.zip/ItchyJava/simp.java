class simp {

public static void main(String[] args) {
	System.out.println("Hobo");
	System.out.print(5);
	System.out.println(" is my favorite number!");
}

}