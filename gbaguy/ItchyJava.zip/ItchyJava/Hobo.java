import java.io.*;

class Hobo {

public static void main(String[] args) throws Exception {
	BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	System.out.print("Please input a number: ");
	int i = Integer.parseInt(BR.readLine());
	printStrings("You suck ",i," lollipops.");
}

public static void printStrings(String a,int y,String b) {
	Poop p = new Poop();
	System.out.print(a);
	p.printInt(y);
	System.out.println(b);
}

}

class Poop {

public void printInt(int a) {
	System.out.print(a);
}

}