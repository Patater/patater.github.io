import java.io.*;

class inputtest {

public static void main(String[] args) throws Exception {
	BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));
	System.out.print("Input a number: ");
	String i1 = IN.readLine();
	System.out.print("Input another number: ");
	String i2 = IN.readLine();
	System.out.println("I will subtract them.");
	int a = Integer.parseInt(i1);
	int b = Integer.parseInt(i2);
	System.out.println("The sum is " + (a-b) + ".");
}

}