using System;
using IO = System.IO;
using WinForms = System.Windows.Forms;
using Coll = System.Collections;

/* This file contains the implementation of java.awt 
 * Originally written by Mike H (aka GbaGuy, ASMGuy, generally *Guy) vbnetprogramer@hotmail.com
 * http://k2pts.home.comcast.net/gbaguy/
 * This file v0.0.0.1
 * ---
 * All classes will be implemented on release of v0.1.0.0, not all classes do exactly what they
 * should (many buffered classes don't buffer...), and many methods that do a test
 * just contain the line "return false;"...
 * ---
 * This may get released as GPL if it ends up being any good...
 * DO NOT DISTRIBUTE!
*/

namespace java.awt {
	//interfaces
	//public interface ImageObserver {
		// this may end up being an abstract class to simulate required functionality...
	//}
	//classes
	public abstract class Component {
		
	}
}
