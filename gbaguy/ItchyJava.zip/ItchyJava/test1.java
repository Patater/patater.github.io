import java.io.*;

class test1 {

public test1() {
	System.out.println("This rocks!");
}

public static void main(String[] args) {
	new test1();
}

}