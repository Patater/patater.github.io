import java.net.*;
import java.io.*;

class web {

public web() throws Exception {
	URL u = new URL("http://www.google.com");
	BufferedReader IN = new BufferedReader(new InputStreamReader(u.openStream()));
	for(int i=0;i<34;i++) {
		System.out.println(IN.readLine());
	}
}

public static void main(String[] args) throws Exception {
	new web();
}

}