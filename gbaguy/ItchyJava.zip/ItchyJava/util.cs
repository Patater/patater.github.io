using System;
using IO = System.IO;
using Coll = System.Collections;

/* This file contains the implementation of java.util 
 * Originally written by Mike H (aka GbaGuy, ASMGuy, generally *Guy) vbnetprogramer@hotmail.com
 * http://k2pts.home.comcast.net/gbaguy/
 * This file v0.0.0.1
 * ---
 * All classes will be implemented on release of v0.1.0.0, not all classes do exactly what they
 * should (many buffered classes don't buffer...), and many methods that do a test
 * just contain the line "return false;"...
 * ---
 * This may get released as GPL if it ends up being any good...
 * DO NOT DISTRIBUTE!
*/

namespace java.util {
	//interfaces
	public interface Enumeration {
		bool HasMoreElements();
		object NextElement();
	}
	public interface EventListener {}
	//classes
	public class Random : System.Random {
		public Random() : base() {}
		public Random(long seed) : base((int)seed) {}
		public void SetSeed(long seed) {} // irrelevant really...
		//public void NextBytes(byte[] bytes) {} inherits an identical method, thanks .NET!
		public int NextInt() {return (int)base.NextDouble()*100;}
		public long NextLong() {return (long)base.NextDouble()*1000;}
		public float NextFloat() {return (float)base.NextDouble();}
		public double NextGaussian() {return base.NextDouble();} // should this do something else?
	}
	public class Hashtable : Dictionary {
		Coll.Hashtable hash;
		public Hashtable() {hash = new Coll.Hashtable();}
		public Hashtable(int cap) {hash = new Coll.Hashtable(cap);}
		public Hashtable(int cap,float f) {f=f; hash=new Coll.Hashtable(cap);}
		public override int Size() {return hash.Keys.Count;}
		public override bool IsEmpty() {return hash.Count==0;}
		public override Enumeration Keys() {return (Enumeration) new Itchy.EnumHelp(hash.Keys);}
		public override Enumeration Elements() {return (Enumeration) new Itchy.EnumHelp(hash.Values);}
		public bool Contains(object value) {return hash.ContainsValue(value);}
		public bool ContainsKey(object key) {return hash.ContainsKey(key);}
		public override object Get(object key) {return hash[key];}
		public override object Put(object key,object value) {
			object o = hash[key];
			hash[key] = value;
			return o;
		}
		public override object Remove(object key) {
			object o = hash[key];
			hash.Remove(key);
			return o;
		}
		public void Clear() {hash.Clear();}
		public object Clone() {return hash.Clone();}
	}
	public abstract class Dictionary {
		public Dictionary() {}
		public abstract int Size();
		public abstract bool IsEmpty();
		public abstract Enumeration Keys();
		public abstract Enumeration Elements();
		public abstract object Get(object key);
		public abstract object Put(object key,object value);
		public abstract object Remove(object key);
	}
	public class EventObject {
		public object source;
		public override string ToString() {return source.ToString();}
		public object GetSource() {return source;}
		public EventObject(object s) {source=s;}
	}
	public class Date {
		System.DateTime DT;
		public Date() {DT = DateTime.Now;}
		public Date(long time) {DT = DateTime.FromFileTime(time);} // unknown if that is right.
		public long GetTime() {return DT.Ticks;}
		public void SetTime(long time) {DT = DateTime.FromFileTime(time);} // ditto
		public bool Before(Date when) { 
			if(when.DT.CompareTo(DT)==-1) return true;
			return false;
		}
		public bool After(Date when) {
			if(when.DT.CompareTo(DT)==1) return true;
			return false;
		}
		public override bool Equals(Object when) {
			if(when==null||!(when is Date))
				return false;
			Date t =(Date) when;
			if(t.DT.ToFileTime()==DT.ToFileTime())
				return true;
			return false;
		}
		public override int GetHashCode() {return base.GetHashCode();}
		public override string ToString() {return DT.ToString();}
		public int HashCode() {return GetHashCode();}
	}
}
