using System;
using IO = System.IO;
using WinForms = System.Windows.Forms;
using Coll = System.Collections;
using SOCK = System.Net.Sockets;
using NET = System.Net;
using WEB = System.Web;

/* This file contains the implementation of java.net 
 * Originally written by Mike H (aka GbaGuy, ASMGuy, generally *Guy) vbnetprogramer@hotmail.com
 * http://k2pts.home.comcast.net/gbaguy/
 * This file v0.0.0.1
 * ---
 * All classes will be implemented on release of v0.1.0.0, not all classes do exactly what they
 * should (many buffered classes don't buffer...), and many methods that do a test
 * just contain the line "return false;"...
 * ---
 * This may get released as GPL if it ends up being any good...
 * DO NOT DISTRIBUTE!
*/

namespace java.net {
	public class URL {
		string url;
		public URL(string u) {url = u;}
		public java.io.InputStream OpenStream() {
			NET.WebClient wc = new NET.WebClient();
			return (java.io.InputStream) new Itchy.ItchyInputStream(wc.OpenRead(url));
		}
	}
	public class Socket {
		//incomplete and doesn't work, always errors on Bind
		SocketImpl SI;
		public Socket() {}
		public Socket(SocketImpl s) {SI=s;}
		public Socket(string host,int port) {
			SI =(SocketImpl) new Itchy.ItchySocketImpl();
			SI.Connect(host,port);
		}
		public Socket(InetAddress address,int port) {
			SI =(SocketImpl) new Itchy.ItchySocketImpl();
			SI.Connect(address,port);
		}
		public Socket(string host,int port,InetAddress localAddr,int localPort) {
			SI =(SocketImpl) new Itchy.ItchySocketImpl();
			SI.Connect(host,port);
			SI.Bind(localAddr,localPort);
		}
		public Socket(InetAddress address,int port,InetAddress localAddr,int localPort) {
			SI =(SocketImpl) new Itchy.ItchySocketImpl();
			SI.Connect(address,port);
			SI.Bind(localAddr,localPort);
		}
		public java.io.OutputStream GetOutputStream() {return SI.GetOutputStream();}
		public java.io.InputStream GetInputStream() {return SI.GetInputStream();}
	}
	public class InetAddress {
		NET.IPAddress ip;
		private InetAddress() {}
		public static InetAddress GetByName(string host) {
			InetAddress IA = new InetAddress();
			NET.IPHostEntry IPHE = NET.Dns.Resolve(host);
			IA.ip = IPHE.AddressList[0];
			return IA;
		}
		public static InetAddress GetLocalHost() {
			InetAddress IA = new InetAddress();
			IA.ip = NET.IPAddress.Parse("127.0.0.1");
			return IA;
		}
		public static InetAddress[] GetAllByName(string host) {
			NET.IPHostEntry IPHE = NET.Dns.Resolve(host);
			InetAddress[] IA = new InetAddress[IPHE.AddressList.Length];
			for(int i=0;i<IA.Length;i++) {
				IA[i] = new InetAddress();
				IA[i].ip = IPHE.AddressList[i];
			}
			return IA;
		}
		public override string ToString() {return ip.ToString();}
		public bool IsMulticastAddress() { return false; } // how do I figure that out?
		public string GetHostName() { return ip.ToString();}
		public byte[] GetAddress() { return ip.GetAddressBytes();}
		public string GetHostAddress() {return ip.ToString();}
		public int HashCode() {return base.GetHashCode();}
		public override int GetHashCode() {return base.GetHashCode();}
		public override bool Equals(object i) {
			if(i==null||!(i is InetAddress))
				return false;
			InetAddress IA =(InetAddress) i;
			if(IA.ip.ToString()==ip.ToString())
				return true;
			return false;
		}
	}
	public abstract class SocketImpl {
		public SocketImpl() {}
		public java.io.FileDescriptor fd = null;
		public InetAddress address = null;
		public int port = 0;
		public int localport = 0;
		public abstract void Create(bool stream);
		public abstract void Connect(string host,int port);
		public abstract void Connect(InetAddress address,int port);
		public abstract void Bind(InetAddress host,int port);
		public abstract void Listen(int backlog);
		public abstract void Accept(SocketImpl s);
		public abstract java.io.InputStream GetInputStream();
		public abstract java.io.OutputStream GetOutputStream();
		public abstract int Available();
		public abstract void Close();
		public java.io.FileDescriptor GetFileDescriptor() {return fd;}
		public InetAddress GetInetAddress() {return address;}
		public int GetPort() {return port;}
		public int GetLocalPort() {return localport;}
		public override string ToString() {return address.ToString() + ":" + port.ToString();}
	}
}
