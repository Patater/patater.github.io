What the heck is this?
----------------------

This is a (largely) unfinished Java VM written in C#.
2 files are extremely important, ClassLoader.cs and VM.cs.
They are what they say they are, ClassLoader will load classes,
and VM will do the interpreting of the Java bytecode (most opcodes
are done, along with everything else, the interpreter isn't complete either).

There are several other code files which are a small sample of Java API
classes, created from a copy of the 1.1 API spec.

How do I use it?
----------------

If you make a simple program (for example, just command-line stuff, input 
with BufferedReader, and output with System.out.println), then you should be
able to run a program in the same way as the Sun Microsystems VM.
Type "VM CLASS_NAME_HERE_NO_EXT" at the DOS (command) prompt.

What can it do right now?
-------------------------

It can run all the Java programs provided in the ItchyJava directory. You
can try and write some programs and see what happens.

Can I improve this thing?
-------------------------

Sure, this program is provided under the terms of the GNU Public License (GPL).
Which means that you have to release the FULL SOURCE CODE of anything you do with
this. And please give me credit if you use a fairly large portion of this.

Can I join you in developing this?
----------------------------------

No, I've moved on from this. Feel free to do whatever you want with it
under the term of the GNU Public License. 

Who wrote this program?
-----------------------

I did. er... you want to know who I am?

I go by GbaGuy quite often, or Mike.

website: http://k2pts.home.comcast.net/gbaguy/
email: vbnetprogramer@hotmail.com

Thanks to:
----------

DeveloperFusion.com - A great site for Windows development.
Sun Microsystems - Making Java the piece-of-shit that it is to get anything useful done.
Microsoft Corp. - Making my favorite OS (I hate Linux, I hate it, I hate it...)
Nintendo of America/Japan - Never releasing SDKs for any of their systems, bastards...
Me - Spending time not doing my homework and letting my (high school) grades go down
	the drain.
You - reading this and making it worth my time.








