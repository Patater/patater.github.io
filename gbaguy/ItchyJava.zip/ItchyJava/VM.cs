using System;
using System.IO;
using System.Collections;
using System.Reflection;

public class VM {
	public static Hashtable LoadedClasses = new Hashtable();
	public static ClassLoader Loader = new ClassLoader();
	public static Stack stack;
	public static Hashtable locals;
	
	public static void RunApplication(string classname) {
		Class c = Loader.LoadClass(classname);
		new VM(c);
	}
	
	public VM(Class runclass) {
		#if DEBUG
			Console.WriteLine("Running \"main\" method...");
			Console.WriteLine("---");
		#endif
		LoadedClasses[runclass.Name] = runclass;
		RunMethod(runclass,"main",new Stack(),new Hashtable());
	}
	
	private void RunMethod(Class c,string method,Stack s,Hashtable l) {
		byte[] code = GetMethodByteCode(c,method);
		if(code==null) return;
		stack = s;
		locals = l;
		RunByteCode(c,code);
	}
	
	private void RunByteCode(Class c,byte[] code) {
		Stack s =(Stack) stack.Clone();
		Hashtable l =(Hashtable) locals.Clone();
		for(int i=0;i<code.Length;i++) {
			byte op = code[i];
			switch(op) {
				case 1:
					//aconst_null
					s.Push(null);
					break;
				case 2:
					//iconst_m1
					s.Push(-1);
					break;
				case 3:
					//iconst_0
					s.Push(0);
					break;
				case 4:
					//iconst_1
					s.Push(1);
					break;
				case 5:
					//iconst_2
					s.Push(2);
					break;
				case 6:
					//iconst_3
					s.Push(3);
					break;
				case 7:
					//iconst_4
					s.Push(4);
					break;
				case 8:
					//i_const5
					#if TRACE
						Console.WriteLine("i_const5");
					#endif
					s.Push(5);
					break;
				case 9:
					//lconst_0
					s.Push((long)0);
					break;
				case 10:
					//lconst_1
					s.Push((long)1);
					break;
				case 0xb:
					//fconst_0
					s.Push((float)0.0);
					break;
				case 0xc:
					//fconst_1
					s.Push((float)1.0);
					break;
				case 0xd:
					//fconst_2
					s.Push((float)2.0);
					break;
				case 0xe:
					//dconst_0
					s.Push((double)0.0);
					break;
				case 0xf:
					//dconst_1
					s.Push((double)1.0);
					break;
				case 0x10:
					//bipush
					i++;
					s.Push((int)code[i]);
					break;
				case 0x11:
					//sipush
					i++;
					short si = (short)((((int)code[i])<<8)|code[i+1]);
					s.Push(si);
					i++;
					break;
				case 0x12:
					//ldc
					i++;
					#if TRACE
						Console.WriteLine("ldc #" + code[i].ToString());
					#endif
					CPItem cw =(CPItem) c.ConstantPool[(int)code[i]-1];
					if(cw.value is string) {
						ObjRef swr = new ObjRef();
						swr.Type = "java/lang/String";
						swr.Value = cw.value;
						swr.IsLibraryInstance = true;
						s.Push(swr);
					} else
					s.Push(cw.value);
					break;
				case 0x14:
					//ldc2_w
					CPItem cdd =(CPItem) c.ConstantPool[(int)code[i+1]-1];
					if(cdd.value is string) {
						ObjRef swr = new ObjRef();
						swr.Type = "java/lang/String";
						swr.Value = cdd.value;
						swr.IsLibraryInstance = true;
						s.Push(swr);
					} else
						s.Push(cdd.value);
					i++;
					break;
				case 0x15:
					//iload
					i++;
					s.Push((int)l[(int)code[i]]);
					break;
				case 0x16:
					//lload
					i++;
					s.Push((long)l[(int)code[i]]);
					break;
				case 0x17:
					//fload
					s.Push((float)l[(int)code[++i]]);
					break;
				case 0x18:
					//dload
					s.Push((double)l[(int)code[++i]]);
					break;
				case 0x19:
					//aload
					s.Push(l[(int)code[++i]]);
					break;
				case 0x1a:
					//iload_0
					s.Push((int)l[0]);
					break;
				case 0x1b:
					//iload_1
					#if TRACE
						Console.WriteLine("iload_1");
					#endif
					s.Push((int)l[1]);
					break;
				case 0x1c:
					//iload_2
					s.Push((int)l[2]);
					break;
				case 0x1d:
					//iload_3
					s.Push((int)l[3]);
					break;
				case 0x1e:
					//lload_0
					s.Push((long)l[0]);
					break;
				case 0x1f:
					//lload_1
					s.Push((long)l[1]);
					break;
				case 0x20:
					//lload_2
					s.Push((long)l[2]);
					break;
				case 0x21:
					//lload_3
					s.Push((long)l[3]);
					break;
				case 0x22:
					//fload_0
					s.Push((float)l[0]);
					break;
				case 0x23:
					//fload_1
					s.Push((float)l[1]);
					break;
				case 0x24:
					//fload_2
					s.Push((float)l[2]);
					break;
				case 0x25:
					//fload_3
					s.Push((float)l[3]);
					break;
				case 0x26:
					//dload_0
					s.Push((double)l[0]);
					break;
				case 0x27:
					//dload_1
					s.Push((double)l[1]);
					break;
				case 0x28:
					//dload_2
					s.Push((double)l[2]);
					break;				
				case 0x29:
					//dload_3
					s.Push((double)l[3]);
					break;
				case 0x2A:
					//aload_0
					s.Push(l[0]);
					break;
				case 0x2B:
					//aload_1
					s.Push(l[1]);
					break;
				case 0x2C:
					//aload_2
					s.Push(l[2]);
					break;
				case 0x2D:
					//aload_3
					s.Push(l[3]);
					break;
				case 0x36:
					//istore
					l[(int)code[i+1]] =(int) s.Pop();
					//Console.WriteLine("STORED " + l[4] + " INTO " + code[i+1]);
					i++;
					break;
				case 0x37:
					//lstore
					l[(int)code[i+1]] =(long) s.Pop();
					l[(int)code[i+1]+1] =(long) l[(int)code[i+1]];
					i++;
					break;
				case 0x38:
					//fstore
					l[(int)code[i+1]] = (float) s.Pop();
					i++;
					break;
				case 0x39:
					//dstore
					l[(int)code[i+1]] =(double) s.Pop();
					l[(int)code[i+1]+1] = l[(int)code[i+1]];
					i++;
					break;
				case 0x3a:
					//astore
					l[(int)code[i+1]] = s.Pop();
					i++;
					break;
				case 0x3b:
					//istore_0
					l[0] =(int) s.Pop();
					break;
				case 0x3c:
					//istore_1
					l[1] =(int) s.Pop();
					break;
				case 0x3d:
					//istore_2
					l[2] =(int) s.Pop();
					break;
				case 0x3e:
					//istore_3
					l[3] =(int) s.Pop();
					break;
				case 0x3f:
					//lstore_0
					l[0] =(long) s.Pop();
					l[1] = l[0];
					break;
				case 0x40:
					//lstore_1
					l[1] =(long) s.Pop();
					l[2] = l[1];
					break;
				case 0x41:
					//lstore_2
					l[2] =(long) s.Pop();
					l[3] =(long) l[2];
					break;
				case 0x42:
					//lstore_3
					l[3] =(long) s.Pop();
					l[4] = l[3];
					break;
				case 0x43:
					//fstore_0
					l[0] =(float) s.Pop();
					break;
				case 0x44:
					//fstore_1
					l[1] =(float) s.Pop();
					break;
				case 0x45:
					//fstore_2
					l[2] =(float) s.Pop();
					break;
				case 0x46:
					//fstore_3
					l[3] =(float) s.Pop();
					break;
				case 0x47:
					//dstore_0
					l[0] =(double) s.Pop();
					l[1] = l[0];
					break;
				case 0x48:
					//dstore_1
					l[1] =(double) s.Pop();
					l[2] = l[1];
					break;	
				case 0x49:
					//dstore_2
					l[2] =(double) s.Pop();
					l[3] = l[2];
					break;
				case 0x4A:
					//dstore_3
					l[3] =(double) s.Pop();
					l[4] = l[3];
					break;
				case 0x4B:
					//astore_0
					l[0] = s.Pop();
					break;
				case 0x4C:
					//astore_1
					l[1] = s.Pop();
					break;				
				case 0x4D:
					//astore_2
					l[2] = s.Pop();
					break;
				case 0x4E:
					//astore_3
					l[3] = s.Pop();
					break;
				case 0x57:
					//pop
					//if(IsCat1(s.Peek()))
					s.Pop();
					break;
				case 0x58:
					//pop2
					//if(IsCat1(s.Peek())
					//s.Pop();
					//else {
					s.Pop();
					s.Pop();
					// }
					break;
				case 0x59:
					//dup
					#if TRACE
						Console.WriteLine("dup");
					#endif
					s.Push(s.Peek());
					break;
				case 0x5f:
					//swap
					object a3 = s.Pop();
					object b3 = s.Pop();
					s.Push(a3);
					s.Push(b3);
					break;
				case 0x60:
					//iadd
					int a =(int) s.Pop();
					int b =(int) s.Pop();
					s.Push(a+b);
					break;
				case 0x61:
					//ladd
					long aaa =(long) s.Pop();
					long bbb =(long) s.Pop();
					s.Push(aaa+bbb);
					break;
				case 0x62:
					//fadd
					float r3 =(float) s.Pop();
					float r51 =(float) s.Pop();
					s.Push((float)((r3)+r51));
					break;
				case 0x63:
					//dadd
					double ks =(double) s.Pop();
					double sk =(double) s.Pop();
					s.Push(ks+sk);
					break;
				case 0x64:
					//isub
					int dd44 =(int) s.Pop();
					int se44 =(int) s.Pop();
					s.Push((int)(se44-dd44));
					break;
				case 0x65:
					//lsub
					long kk2 =(long) s.Pop();
					long kk1 =(long) s.Pop();
					s.Push((long)(kk1-kk2));
					break;
				case 0x66:
					//fsub
					float ku1 =(float) s.Pop();
					float ku2 =(float) s.Pop();
					s.Push((float)(ku2-ku1));
					break;
				case 0x68:
					//imul
					int kk5 =(int) s.Pop();
					int kk88 =(int) s.Pop();
					s.Push((int)(kk5*kk88));
					break;
				case 0x69:
					//lmul
					long kk21 =(long) s.Pop();
					long lls =(long) s.Pop();
					s.Push(lls*kk21);
					break;
				case 0x6A:
					//fmul
					float r5 =(float) s.Pop();
					float r6 =(float) s.Pop();
					s.Push(r5*r6);
					break;
				case 0x6c:
					//idiv
					int a1 =(int) s.Pop();
					int b1 =(int) s.Pop();
					s.Push(b1/a1);
					break;
				case 0x6D:
					//ldiv
					long aa4 =(long) s.Pop();
					long bb4 =(long) s.Pop();
					s.Push(bb4/aa4);
					break;
				case 0x6e:
					//fdiv
					float a43 =(float) s.Pop();
					float b43 =(float) s.Pop();
					s.Push(b43/a43);
					break;
				case 0x71:
					//lrem
					long ee4 =(long) s.Pop();
					long bb5 =(long) s.Pop();
					s.Push(bb5%ee4);
					break;
				case 0x75:
					//lneg
					s.Push(0-(long)s.Pop());
					break;
				case 0x7E:
					//iand
					int sa1 =(int) s.Pop();
					int ds1 =(int) s.Pop();
					s.Push((int)(sa1&ds1));
					break;
				case 0x7F:
					//land
					long dd1 =(long) s.Pop();
					long sx =(long) s.Pop();
					s.Push((long)(dd1&sx));
					break;
				case 0x81:
					//lor
					long dd2 =(long) s.Pop();
					long dd3 =(long) s.Pop();
					s.Push((long)(dd2|dd3));
					break;
				case 0x83:
					//lxor
					long dd4 =(long) s.Pop();
					long dd5 =(long) s.Pop();
					s.Push((long)(dd4^dd5));
					break;
				case 0x84:
					//iinc
					l[(int)code[i+1]] = (int)(((int)l[(int)code[i+1]]) + (int)code[i+2]);
					i+=2;
					break;
				case 0x85:
					//i2l
					s.Push((long)(int)s.Pop());
					break;
				case 0x86:
					//i2f
					s.Push((float)(int)s.Pop());
					break;
				case 0x87:
					//i2d
					s.Push((double)(int)s.Pop());
					break;
				case 0x88:
					//l2i
					s.Push((int)(long)s.Pop());
					break;
				case 0x89:
					//l2f
					s.Push((float)(long)s.Pop());
					break;
				case 0x8a:
					//l2d
					s.Push((double)(long)s.Pop());
					break;
				case 0x8b:
					//f2i
					s.Push((int)(float)s.Pop());
					break;
				case 0x8c:
					//f2l
					s.Push((long)(float)s.Pop());
					break;
				case 0x8D:
					//f2d
					s.Push((double)(float)s.Pop());
					break;
				case 0x8E:
					//d2i
					s.Push((int)(double)s.Pop());
					break;
				case 0x8F:
					//d2l
					s.Push((long)(double)s.Pop());
					break;
				case 0x90:
					//d2f
					s.Push((float)(double)s.Pop());
					break;
				case 0x91:
					//i2b
					s.Push((byte)(int)s.Pop());
					break;
				case 0x92:
					//i2c
					s.Push((char)(int)s.Pop());
					break;
				case 0x93:
					//i2s
					s.Push((short)(int)s.Pop());
					break;
				case 0x94:
					//lcmp
					long vv2 =(long) s.Pop();
					long vv1 =(long) s.Pop();
					if(vv1>vv2)
						s.Push(1);
					else if(vv1<vv2)
						s.Push(-1);
					else
						s.Push(0);
					break;
				case 0x96:
					//fcmpg
					float vk24 =(float) s.Pop();
					float vk14 =(float) s.Pop();
					if(vk14>vk24)
						s.Push(1);
					else if(vk14<vk24)
						s.Push(-1);
					else
						s.Push(0);
					break;
				case 0x99:
					//ifeq
					i++;
					if((int)s.Pop()==0) {
						int gad = (int)((((int)code[i])<<8)|code[i+1]);
						if((gad&0x8000)!=0)
							gad = (gad - 65536);
						i += gad-2;
						break;
					} 
					i++;
					break;
				case 0x9a:
					//ifne
					i++;
					if((int)s.Pop()!=0) {
						int ga1 = (int)((((int)code[i])<<8)|code[i+1]);
						if((ga1&0x8000)!=0)
							ga1 = (ga1 - 65536);
						i += ga1-2;
						break;
					} 
					i++;
					break;
				case 0x9B:
					//iflt
					i++;
					if((int)s.Pop()<0) {
						int g9 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g9&0x8000)!=0)
							g9 = (g9 - 65536);
						i += g9-2;
						break;
					} 
					i++;
					break;
				case 0x9C:
					//ifle
					i++;
					if((int)s.Pop()<=0) {
						int g8 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g8&0x8000)!=0)
							g8 = (g8 - 65536);
						i += g8-2;
						break;
					} 
					i++;
					break;
				case 0x9D:
					//ifgt
					i++;
					if((int)s.Pop()>0) {
						int g7 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g7&0x8000)!=0)
							g7 = (g7 - 65536);
						i += g7-2;
						break;
					} 
					i++;
					break;
				case 0x9E:
					//ifge
					i++;
					if((int)s.Pop()>=0) {
						int g6 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g6&0x8000)!=0)
							g6 = (g6 - 65536);
						i += g6-2;
						break;
					} 
					i++;
					break;
				case 0x9F:
					//if_icmpeq
					i++;
					int vv23 =(int) s.Pop();
					int vv13 =(int) s.Pop();
					if(vv13==vv23) {
						int g5 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g5&0x8000)!=0)
							g5 = (g5 - 65536);
						i += g5-2;
						break;
					} 
					i++;
					break;
				case 0xA0:
					//if_icmpne
					i++;
					int vv3 =(int) s.Pop();
					int vv4 =(int) s.Pop();
					if(vv4!=vv3) {
						int g4 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g4&0x8000)!=0)
							g4 = (g4 - 65536);
						i += g4-2;
						break;
					} 
					i++;
					break;
				case 0xA1:
					//if_icmplt
					i++;
					int vv5 =(int) s.Pop();
					int vv6 =(int) s.Pop();
					if(vv6<vv5) {
						int g3 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g3&0x8000)!=0)
							g3 = (g3 - 65536);
						i += g3-2;
						break;
					} 
					i++;
					break;
				case 0xA2:
					//if_icmpge
					i++;
					int vv7 =(int) s.Pop();
					int vv8 =(int) s.Pop();
					//Console.WriteLine("Comparing " + vv8 + " and " + vv7);
					if(vv8>=vv7) {
						int g2 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g2&0x8000)!=0)
							g2 = (g2 - 65536);
						i += g2-2;
						//Console.WriteLine("i is {0}",i);
						//Console.WriteLine("The next opcode is {0:X}",code[i]);
						break;
					} 
					i++;
					break;
				case 0xA3:
					//if_icmpgt
					i++;
					int vv9 =(int) s.Pop();
					int vv00 =(int) s.Pop();
					if(vv00>vv9) {
						int g1 = (int)((((int)code[i])<<8)|code[i+1]);
						if((g1&0x8000)!=0)
							g1 = (g1 - 65536);
						i += g1-2;
						break;
					} 
					i++;
					break;
				case 0xA4:
					//if_icmple
					i++;
					int vv11 =(int) s.Pop();
					int vv12 =(int) s.Pop();
					if(vv12<=vv11) {
						int g1c = (int)((((int)code[i])<<8)|code[i+1]);
						if((g1c&0x8000)!=0)
							g1c = (g1c - 65536);
						i += g1c-2;
						//Console.WriteLine("Opcode after if_icmple is 0x{0:X}",code[i]);
						break;
					} 
					i++;
					break;
				case 0xa7:
					//goto
					i++;
					int g = (int)((((int)code[i])<<8)|code[i+1]);
					if((g&0x8000)!=0)
						g = (g - 65536);
					i += g-2;
					break;
				case 0xb2:
					//getstatic
					i++;
					int d = (int)((((int)code[i])<<8)|code[i+1]);
					string varname;
					CPItem c21 =(CPItem) c.ConstantPool[d-1];
					int bb =(int) c21.others[0];
					d =(int) c21.others[1];
					CPItem c34 =(CPItem) c.ConstantPool[d-1];
					d =(int) c34.others[1];
					int aa =(int) c34.others[0];
					c34 =(CPItem) c.ConstantPool[d-1];
					ObjRef s2 = new ObjRef();
					s2.StaticClass = true;
					s2.Type = (string)c34.value;
					s2.Type = s2.Type.Substring(1,s2.Type.Length-2);
					c21 =(CPItem) c.ConstantPool[aa-1];
					varname =(string) c21.value;
					c21 =(CPItem) c.ConstantPool[bb-1];
					varname =(string) c21.value + "." + varname;
					s2.Name = varname;
					CreateStaticRef(s2);
					s.Push(s2);
					i++;
					break;
				case 0xb6:
					//invokevirtual
					i++;
					int d1 = (int)((((int)code[i])<<8)|code[i+1]);
					CPItem c22 =(CPItem) c.ConstantPool[d1-1];
					InvokeMethod(c,c22,s);
					i++;  // needed?
					break;
				case 0xb7:
					//invokespecial
					i++;
					int d23 = (int)((((int)code[i])<<8)|code[i+1]);
					CPItem c2223 =(CPItem) c.ConstantPool[d23-1];
					InvokeMethod(c,c2223,s);
					i++;  // needed?
					break;	
				case 0xb8:
					//invokestatic
					i++;
					int d24 = (int)((((int)code[i])<<8)|code[i+1]);
					CPItem c2323 =(CPItem) c.ConstantPool[d24-1];
					InvokeStatic(c,c2323,s);
					i++;  // needed?
					break;	
				case 0xbb:
					//new
					i++;
					ObjRef ornew = new ObjRef();
					int sym1 = (int)((((int)code[i])<<8)|code[i+1]);
					CPItem c24 =(CPItem) c.ConstantPool[sym1-1];
					ornew.Type =(string) c24.value;
					if(ornew.Type.StartsWith("java"))
						ornew.IsLibraryInstance = true;
					else {
						if(!LoadedClasses.ContainsKey(ornew.Type))
							LoadedClasses[ornew.Type] = Loader.LoadClass(ornew.Type);
						ornew.Object =(Class) LoadedClasses[ornew.Type];
					}
					s.Push(ornew);
					i++; //needed?
					break;
				case 0xb1:
					//return
					//Console.WriteLine("RETURNED");
					return;
				case 0xc6:
					//ifnull
					i++;
					if(s.Pop()==null) {
						int g2g = (int)((((int)code[i])<<8)|code[i+1]);
						if((g2g&0x8000)!=0)
							g2g = (g2g - 65536);
						i += g2g-1;
						break;
					} 
					i++;
					break;
				case 0xc7:
					//ifnonnull
					i++;
					if(s.Pop()!=null) {
						int g2d = (int)((((int)code[i])<<8)|code[i+1]);
						if((g2d&0x8000)!=0)
							g2d = (g2d - 65536);
						i += g2d-1;
						break;
					} 
					i++;
					break;					
			}
		}
	}
	
	private void CreateStaticRef(ObjRef stat) {
		object LibF;
		Assembly asm = Assembly.GetExecutingAssembly();
		//Console.WriteLine("STATNAME==" + stat.Name);
		string cname = stat.Name.Substring(0,stat.Name.IndexOf("."));
		cname = cname.Replace("/",".");
		string field = stat.Name.Substring(stat.Name.IndexOf(".")+1);
		//Console.WriteLine("Static class name = " + cname + ",field=" + field);
		Type objType = Type.GetType(cname,true,true);
		field = (field[0].ToString()).ToUpper() + field.Substring(1);
		System.Reflection.FieldInfo FI = objType.GetField(field);
		LibF = FI.GetValue(null);
		stat.Value = LibF;
	}
	
	private void InvokeStatic(Class caller,CPItem method,Stack s) {
		string classname =(string) ((CPItem)caller.ConstantPool[(int)method.others[0]-1]).value;
		int index =(int) ((CPItem)caller.ConstantPool[(int)method.others[1]-1]).others[0];
		string methodname =(string) ((CPItem)caller.ConstantPool[index-1]).value;
		index =(int) ((CPItem)caller.ConstantPool[(int)method.others[1]-1]).others[1];
		string mtypes =(string) ((CPItem)caller.ConstantPool[index-1]).value;
		#if TRACE
			Console.WriteLine(classname + "." + methodname + mtypes + " Invoked");
		#endif
		ArrayList args = new ArrayList();
		int armount = GetArgAmount(mtypes);
		for(int i=0;i<armount;i++) {
			args.Add(s.Pop());
		}
		//Console.WriteLine("METHOD '" + methodname + "' called on OBJ=");
		if(classname.StartsWith("java/")) {
			ObjRef or = new ObjRef();
			or.StaticClass = true;
			or.Type = classname;
			InvokeLibraryMethod(or,methodname,mtypes,args,caller,s);
			return;
		} else {
			InvokeStaticMethod(classname,methodname,mtypes,args,caller,s);
		}
	}
	
	private void InvokeStaticMethod(string clas,string meth,string mt,ArrayList al,Class caller,Stack s) {
		if(!LoadedClasses.ContainsKey(clas))
			LoadedClasses[clas] = Loader.LoadClass(clas);
		Class c =(Class) LoadedClasses[clas];
		for(int i=0;i<al.Count;i++)
			locals[i] = al[al.Count-i-1];
		RunMethod(c,meth,s,locals);
	}
	
	private void InvokeUserMethod(ObjRef or,string classname,string meth,string mt,ArrayList al,Class caller,Stack s) {
		if(meth=="<init>"&&classname=="java/lang/Object")
			return;
		Class c =(Class) or.Object;
		locals[0] = or;
		for(int i=0;i<al.Count;i++)
			locals[1+i] = al[al.Count-i-1];
		RunMethod(c,meth,s,locals);
	}
	
	private void InvokeMethod(Class caller,CPItem method,Stack s) {
		string classname =(string) ((CPItem)caller.ConstantPool[(int)method.others[0]-1]).value;
		int index =(int) ((CPItem)caller.ConstantPool[(int)method.others[1]-1]).others[0];
		string methodname =(string) ((CPItem)caller.ConstantPool[index-1]).value;
		index =(int) ((CPItem)caller.ConstantPool[(int)method.others[1]-1]).others[1];
		string mtypes =(string) ((CPItem)caller.ConstantPool[index-1]).value;
		#if TRACE
			Console.WriteLine(classname + "." + methodname + mtypes + " Invoked");
		#endif
		ArrayList args = new ArrayList();
		int armount = GetArgAmount(mtypes);
		for(int i=0;i<armount;i++) {
			args.Add(s.Pop());
		}
		ObjRef or =(ObjRef) s.Pop();
		if(or.Object==null) {
			InvokeLibraryMethod(or,methodname,mtypes,args,caller,s);
			return;
		} else {
			InvokeUserMethod(or,classname,methodname,mtypes,args,caller,s);
		}
	}
	
	private string CreateDescriptorString(string par) {
		string des = "";
		if(!par.EndsWith(","))
			par += ",";
		while(par!="") {
			if(par.StartsWith("System.Int32")) {
				des += "I";
				par = par.Substring(12);
				continue;
			}
			if(par.StartsWith("System.Int64")) {
				des += "J";
				par = par.Substring(12);
				continue;
			}
			if(par.StartsWith("System.Int16")) {
				des += "S";
				par = par.Substring(12);
				continue;
			}
			if(par.StartsWith("System.Boolean")) {
				des += "Z";
				par = par.Substring(14);
				continue;
			}
			if(par.StartsWith("System.Byte")) {
				des += "B";
				par = par.Substring(11);
				continue;
			}
			if(par.StartsWith("System.Char")) {
				des += "C";
				par = par.Substring(11);
				continue;
			}
			if(par.StartsWith("System.Single")) {
				des += "F";
				par = par.Substring(13);
				continue;
			}
			if(par.StartsWith("System.Double")) {
				des += "D";
				par = par.Substring(13);
				continue;
			}
			if(par.StartsWith("System.String")) {
				des += "Ljava.lang.String;";
				par = par.Substring(13);
				continue;
			}
			string a = par.Substring(0,par.IndexOf(",")+1);
			if(a==",")
				return des;
			des += "L" + a + ";";
			par = par.Substring(a.Length);
		}
		return des;
	}
	
	private bool Match(string par,string des) {
		par = CreateDescriptorString(par);
		if(par==des)
			return true;
		return false;
	}
	
	private void CallLibraryMethod(ObjRef obj,string name,string des,ArrayList Args,Class c,Stack s) {
		string type = obj.Type.Replace("/",".");
		des = des.Substring(1);
		des = des.Substring(0,des.IndexOf(")"));
		des = des.Replace("/",".");
		Assembly asm = Assembly.GetExecutingAssembly();
		Type LibType = asm.GetType(type,true,true);
		MethodInfo[] ci = LibType.GetMethods();
		MethodInfo method = null;
		foreach(MethodInfo CI in ci) {
			if(CI.Name.ToLower()!=name.ToLower())
				continue;
			ParameterInfo[] pi = CI.GetParameters();
			string parTypeString = "";
			foreach(ParameterInfo PI in pi)
				parTypeString += PI.ParameterType + ",";
			if(Match(parTypeString,des)) {
				method = CI;
				break;
			}
		}
		object LibObj = obj.Value;
		Args.TrimToSize();
		object[] oargs = new object[Args.Count];
		for(int i=0;i<Args.Count;i++) {
			object o = Args[i];
			if(o is ObjRef) {
				ObjRef OR =(ObjRef) o;
				oargs[i] = OR.Value;
			} else 
				oargs[i] = o;
		}
		object retval = method.Invoke(LibObj,oargs);
		if(method.ReturnType!=typeof(void)) {
			if(!(retval is int)&&!(retval is long)&&!(retval is string)) {
				ObjRef orret = new ObjRef();
				orret.Type = retval.GetType().ToString();
				orret.Value = retval;
				orret.IsLibraryInstance = true;
				s.Push(orret);
			} else
				s.Push(retval);
		}
		obj.Value = LibObj;
		obj.Type = LibType.ToString();
		obj.IsLibraryInstance = true;
	}
	
	private void CreateLibraryInstance(ObjRef obj,string name,string des,ArrayList Args,Class c,Stack s) {
		string type = obj.Type.Replace("/",".");
		des = des.Substring(1);
		des = des.Substring(0,des.IndexOf(")"));
		des = des.Replace("/",".");
		Assembly asm = Assembly.GetExecutingAssembly();
		Type LibType = asm.GetType(type,true,true);
		if(name!="<init>") {
			Console.WriteLine("Unexpected, the name didn't equal <init> in CreateLibraryInstance");
			Console.WriteLine("Name was " + name);
			Environment.Exit(0);
		}
		object LibObj;
		for(int i=0;i<Args.Count;i++) {
			object o = Args[i];
			if(o is ObjRef) {
				ObjRef OR =(ObjRef) o;
				Args[i] = OR.Value;
			}
		}
		object[] oargs = new object[Args.Count];
		for(int i=0;i<oargs.Length;i++)
			oargs[i] = Args[Args.Count-i-1];
		LibObj = Activator.CreateInstance(LibType,BindingFlags.Default|BindingFlags.InvokeMethod,null,oargs,System.Globalization.CultureInfo.CurrentCulture);
		obj.Value = LibObj;
		obj.Type = LibType.ToString();
		obj.IsLibraryInstance = true;
	}
	
	private void InvokeLibraryMethod(ObjRef obj,string name,string des,ArrayList Args,Class c,Stack s) {
		//Console.WriteLine("METHOD '" + name + "' OF CLASS '" + obj.Type + "' NOT IMPLEMENTED");
		if(obj.IsLibraryInstance) {
			if(name=="<init>") {
				CreateLibraryInstance(obj,name,des,Args,c,s);
				return;
			} else {
				CallLibraryMethod(obj,name,des,Args,c,s);
				return;
			}
		}
		if(obj.StaticClass&&obj.Type.StartsWith("java/")) {
			CallLibraryMethod(obj,name,des,Args,c,s);
			return;
		}
	}
	
	private int GetArgAmount(string pro) {
		int count = 0;
		for(int i=0;i<pro.Length;i++) {
			if(pro[i]=='B'||pro[i]=='C'||pro[i]=='D'||pro[i]=='F')
				count++;
			if(pro[i]=='J'||pro[i]=='I'||pro[i]=='S'||pro[i]=='Z')
				count++;
			if(pro[i]=='L') {
				count++;
				i = pro.IndexOf(";",i+1);
			}
			if(pro[i]==')') {
				//Console.WriteLine("Method has " + count + " args.");
				return count;
			}
		}
		return count;
	}
	
	private byte[] GetMethodByteCode(Class c,string method) {
		foreach(FieldInfo fi in c.Methods) {
			if(fi.Name==method) {
				return fi.Code.ByteCode;
			}
		}
		return null;
	}
	
	public static void Main(string[] args) {
		if(args.Length<1) {
			Console.WriteLine("ItchyJava by Mike H");
			return;
		}
		VM.RunApplication(args[0]);
	}
}

public class ObjRef {
	public Class Object;
	public Hashtable Fields = new Hashtable();
	public string Name;
	public bool ValueType = false;
	public object Value;
	public string Type;
	public bool IsLibraryInstance = false;
	public bool StaticClass = false;
	public override string ToString() {
		return Value.ToString();
	}
}
