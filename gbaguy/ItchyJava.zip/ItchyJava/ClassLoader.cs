using System;
using System.IO;
using System.Collections;

public class ClassLoader {
		
	public Class LoadClass(string classname) {
		Class c = new Class();
		StreamReader SR = new StreamReader(classname + ".class");
		BinaryReader BR = new BinaryReader(SR.BaseStream);
		c.Magic = Readu4(BR);
		if(c.Magic!=-889275714)
			throw new Exception("Invalid Class File.");
		c.MinorV = Readu2(BR);
		c.MajorV = Readu2(BR);
		c.ConstantPoolCount = Readu2(BR);
		#if DEBUG
			Console.WriteLine("Class File Format " + c.MajorV.ToString() + "." + c.MinorV.ToString());
		#endif
		LoadConstantPool(BR,c);
		c.AccessFlags = Readu2(BR);
		c.Name = (string)((CPItem)c.ConstantPool[Readu2(BR)-1]).value;
		#if DEBUG
			Console.WriteLine("Class identified as " + c.Name);
		#endif
		c.Super = (string)((CPItem)c.ConstantPool[Readu2(BR)-1]).value;
		#if DEBUG
			Console.WriteLine("Class " + c.Name + " found to extend " + c.Super);
		#endif
		c.InterfacesCount = Readu2(BR);
		// Could be a problem + or - one interface here... :(
		if(c.InterfacesCount>0) {
			c.Interfaces = new int[c.InterfacesCount];
			for(int i=0;i<c.InterfacesCount;i++)
				c.Interfaces[i] = Readu2(BR);
		}
		c.FieldsCount = Readu2(BR);
		if(c.FieldsCount>0)
			LoadFields(BR,c);
		c.MethodsCount = Readu2(BR);
		if(c.MethodsCount>0)
			LoadMethods(BR,c);
		BR.Close();
		SR.Close();
		return c;
	}
	
	private void PrintListofMethods(Class c) {
		foreach(FieldInfo FI in c.Methods) {
			Console.WriteLine(FI.Name + "<>" + FI.Descriptor);
		}
	}
	
	private void PrintAllStringConstants(Class c) {
		foreach(CPItem cp in c.ConstantPool) {
			if(cp.type!=8)
				continue;
			Console.WriteLine("---");
			Console.WriteLine(cp.value);
			Console.WriteLine("---");
		}
	}
	
	private void LoadMethods(BinaryReader BR,Class c) {
		c.Methods = new FieldInfo[c.MethodsCount];
		for(int i=0;i<c.MethodsCount;i++) {
			c.Methods[i] = new FieldInfo();
			FieldInfo FI = c.Methods[i];
			FI.AccessFlags = Readu2(BR);
			FI.Name = (string)((CPItem)c.ConstantPool[Readu2(BR)-1]).value;
			FI.Descriptor = (string)((CPItem)c.ConstantPool[Readu2(BR)-1]).value;
			FI.AttributeCount = Readu2(BR);
			if(FI.AttributeCount>0)
				LoadAttributes(BR,FI,c);
			if(FI.Code!=null)
				FI.CreateCodeAttribute();
		}
	}
	
	private void LoadFields(BinaryReader BR,Class c) {
		c.Fields = new FieldInfo[c.FieldsCount];
		for(int i=0;i<c.FieldsCount;i++) {
			c.Fields[i] = new FieldInfo();
			FieldInfo FI = c.Fields[i];
			FI.AccessFlags = Readu2(BR);
			FI.Name = (string)((CPItem)c.ConstantPool[Readu2(BR)-1]).value;
			FI.Descriptor = (string)((CPItem)c.ConstantPool[Readu2(BR)-1]).value;
			FI.AttributeCount = Readu2(BR);
			if(FI.AttributeCount>0)
				LoadAttributes(BR,FI,c);
		}
	}
	
	private void LoadAttributes(BinaryReader BR,FieldInfo FI,Class c) {
		FI.Attributes = new AttributeInfo[FI.AttributeCount];
		for(int i=0;i<FI.AttributeCount;i++) {
			FI.Attributes[i] = new CodeAttribute();
			AttributeInfo AI = FI.Attributes[i];
			AI.Name = (string)((CPItem)c.ConstantPool[Readu2(BR)-1]).value;
			AI.Length = Readu4(BR);
			AI.Info = BR.ReadBytes(AI.Length);
			AI.OldAttIndex = i;
			if(AI.Name=="Code")
				FI.Code =(CodeAttribute)AI;
		}
	}
	
	private void LoadConstantPool(BinaryReader BR,Class c) {
		for(int i=0;i<c.ConstantPoolCount-1;i++) {
			byte type =(byte) Readu1(BR);
			switch(type) {
				case 1:
					//UTF-8
					CPItem cc2 = new CPItem();
					cc2.type = type;
					cc2.value = Readu2(BR);
					cc2.others.Add(BR.ReadBytes((int)cc2.value));
					c.ConstantPool.Add(cc2);
					break;
				case 3:
					//Integer
					CPItem CP22 = new CPItem();
					CP22.type = type;
					CP22.value = Readu4(BR);
					c.ConstantPool.Add(CP22);
					break;
				case 4:
					//Float
					CPItem P11 = new CPItem();
					P11.type = type;
					int bits = Readu4(BR);
					int s = ((bits >> 31) == 0) ? 1 : -1;
					int e = ((bits >> 23) & 0xff);
    				int m = (e == 0) ? (bits & 0x7fffff) << 1 : (bits & 0x7fffff) | 0x800000;
					P11.value = (float)(s*m*Math.Pow(2,e-150));
					c.ConstantPool.Add(P11);
					break;
				case 5:
					//Long
					//Double and Long take up 2 constant pool spots for no reason
					//the extra slot is appearantly useless, but why VM no longer 
					//works when I use Double or Long... I don't know :(
					CPItem P23 = new CPItem();
					P23.type = type;
					P23.value = (long)((((long)Readu4(BR))<<32)+Readu4(BR));
					Console.WriteLine(P23.value);
					c.ConstantPool.Add(P23);
					c.ConstantPool.Add(P23);
					break;
				case 6:
					//Double 
					//Double and Long take up 2 constant pool spots for no reason
					//the extra slot is appearantly useless, but why VM no longer 
					//works when I use Double or Long... I don't know :(
					CPItem P24 = new CPItem();
					P24.type = type;
					long bitss = ((long) Readu4(BR) << 32);
					bitss += Readu4(BR);
					int s11 = ((bitss >> 63) == 0) ? 1 : -1;
    				int e11 = (int)((bitss >> 52) & 0x7ffL);
			    	long m11 = (e11 == 0) ? (bitss & 0xfffffffffffffL) << 1 : (bitss & 0xfffffffffffffL) | 0x10000000000000L;
					P24.value = (double)(s11*m11*Math.Pow(2,e11-1075));
					c.ConstantPool.Add(P24);
					c.ConstantPool.Add(P24);
					break;
				case 7:
					//Class
					CPItem C00 = new CPItem();
					C00.type = type;
					C00.value = Readu2(BR);
					c.ConstantPool.Add(C00);
					break;
				case 8:
					//String
					CPItem C32 = new CPItem();
					C32.type = type;
					C32.value = Readu2(BR);
					c.ConstantPool.Add(C32);
					break;
				case 9:
					//Fieldref
					CPItem CP = new CPItem();
					CP.type = type;
					CP.others.Add(Readu2(BR));
					CP.others.Add(Readu2(BR));
					c.ConstantPool.Add(CP);
					break;
				case 10:
					//Methodref
					CPItem CP1 = new CPItem();
					CP1.type = type;
					CP1.others.Add(Readu2(BR));
					CP1.others.Add(Readu2(BR));
					c.ConstantPool.Add(CP1);
					break;
				case 11:
					//InterfaceMethodref
					CPItem Cp = new CPItem();
					Cp.type = type;
					Cp.others.Add(Readu2(BR));
					Cp.others.Add(Readu2(BR));
					c.ConstantPool.Add(Cp);
					break;
				case 12:
					//NameAndType
					CPItem CP55 = new CPItem();
					CP55.type = type;
					CP55.others.Add(Readu2(BR));
					CP55.others.Add(Readu2(BR));
					c.ConstantPool.Add(CP55);
					break;
			}
		}
		#if DEBUG
			Console.WriteLine("Constant Pool Count is " + c.ConstantPool.Count.ToString());
		#endif
		FixUpConstantPool(c);
	}
	
	private void FixUpConstantPool(Class c) {
		foreach(CPItem cc in c.ConstantPool) {
			if(cc.type==1) {
				//Fix up UTF-8 constant
				byte[] s =(byte[]) cc.others[0];
				cc.value = System.Text.Encoding.UTF8.GetString(s,0,s.Length);
			}
		}
		foreach(CPItem cs in c.ConstantPool) {
			if(cs.type==8||cs.type==7) {
				//Fix up String constant
				CPItem cp =(CPItem)c.ConstantPool[((int)cs.value)-1];
				cs.value = cp.value;
			}
		}
	}
	
	public static int Readu4(BinaryReader BR) {
		return (int)(((int)BR.ReadByte()<<24)|((int)BR.ReadByte()<<16)|((int)BR.ReadByte()<<8)|BR.ReadByte());
	}
	
	public static int Readu2(BinaryReader BR) {
		return (int)(((int)BR.ReadByte()<<8)|BR.ReadByte());
	}
	
	public static int Readu1(BinaryReader BR) {
		return (int)BR.ReadByte();
	}
}

public class Class {
	public int MethodsCount;
	public int FieldsCount;
	public int InterfacesCount;
	public int AccessFlags;
	public int ConstantPoolCount;
	public int MajorV;
	public int MinorV;
	public int[] Interfaces;
	public FieldInfo[] Fields;
	public FieldInfo[] Methods;
	public long Magic;
	public string Name;
	public string Super;
	public ArrayList ConstantPool = new ArrayList();
}

public class CodeAttribute : AttributeInfo {
	public int MaxStack;
	public int MaxLocals;
	public int CodeLength;
	public byte[] ByteCode;
	//Not yet supported
	public int ExceptionTableLength;
	public int[][] ExceptionTable;
	public int AttributeCount;
	public AttributeInfo[] Attributes;
}

public class FieldInfo {
	public int AccessFlags;
	public string Name;
	public string Descriptor;
	public string Type;
	public CodeAttribute Code;
	public int AttributeCount;
	public AttributeInfo[] Attributes;
	public void CreateCodeAttribute() {
		Code.MaxStack = (int)(((int)Code.Info[0])<<8|Code.Info[1]);
		Code.MaxLocals = (int)(((int)Code.Info[2])<<8|Code.Info[3]);
		Code.Length = (int)(((int)Code.Info[4]<<24)|((int)Code.Info[5]<<16)|((int)Code.Info[6]<<8)|Code.Info[7]);
		Code.ByteCode = new byte[Code.Length];
		System.Array.Copy(Code.Info,8,Code.ByteCode,0,Code.ByteCode.Length);
	}
}

public class AttributeInfo {
	public string Name;
	public int Length;
	public byte[] Info;
	public int OldAttIndex;
}

public class CPItem {
	public byte type;
	public object value;
	public ArrayList others = new ArrayList();
	public CPItem() {}
}
