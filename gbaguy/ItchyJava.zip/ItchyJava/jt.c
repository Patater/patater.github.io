using java.lang;
using java.io;

class jt {

public static void Main() {
	PrintStream PS = new PrintStream(new FileOutputStream("hobo.txt"));
	PS.Println("I'm not a damn hobo!");
	PS.Println("This should error!");
}

}